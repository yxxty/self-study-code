#include <iostream>
#include <list>

using std::cout;
using std::endl;
using std::list;

template <typename container>
void display(const container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }

    cout << endl;
}

bool operator<(const list<int> &lhs, const list<int> &rhs)
{
    cout << "bool operator<(const, const)" << endl;
    return lhs < rhs;
}

template <typename T>
struct Compare
{
    bool operator()(const T &lhs, const T &rhs) const
    {
        /* cout << "bool operator()(const T &, const T &)" << endl; */
        return lhs > rhs;
    }
};
void test()
{
    list<int> number = {1, 9, 3, 3, 7, 5, 3, 6, 8, 3, 2};
    display(number);

    cout << endl << "测试list的reverse" << endl;
    number.reverse();
    display(number);

    cout << endl << "测试list的sort函数" << endl;
    number.sort();
    /* number.sort(std::less<int>()); */
    /* number.sort(std::greater<int>()); */
    /* number.sort(Compare<int>()); */
    display(number);

    //unique只能去除连续重复的元素
    cout << endl << "测试list的unique" << endl;
    number.unique();
    display(number);

    //两个链表进行merge的时候，要按照相同的排序方式进行排好
    cout << endl << "测试list的merge" << endl;
    list<int> number2 = {10, 30, 50, 4};
    number2.sort();
    display(number2);
    number.merge(number2);
    display(number);
    display(number2);

    cout << endl << "测试list的splice" << endl;
    auto it = number.begin();
    list<int> number3 = {10, 70, 90, 20, 40};
    number.splice(it, number3);
    display(number);
    display(number3);

    cout << endl;
    list<int> number4 = {100, 200, 300, 500, 400};
    it = number.begin();
    ++it;
    auto cit = number4.end();
    --cit;
    number.splice(it, number4, cit);
    display(number);
    display(number4);

    cout << endl;
    it = number.begin();
    ++it;
    ++it;
    auto it2 = number.end();
    --it2;
    --it2;
    number.splice(it2, number, it);
    display(number);

}
int main(int argc, char **argv)
{
    test();
    return 0;
}

