#include <math.h>
#include <iostream>
#include <set>
#include <vector>

using std::cout;
using std::endl;
using std::multiset;
using std::vector;

template <typename container>
void display(const container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }

    cout << endl;
}

void test()
{
    /* multiset<int, std::greater<int>> number = {1, 6, 7, 9, 6, 4, 3, 10, 8}; */
    multiset<int> number = {1, 6, 7, 9, 6, 4, 6, 3, 3, 3, 10, 8};
    display(number);

    cout << endl << "multiset的查找" << endl;
    size_t cnt1 = number.count(6);
    size_t cnt2 = number.count(5);
    cout << "cnt1 = " << cnt1 << endl;
    cout << "cnt2 = " << cnt2 << endl;

    cout << endl;
    multiset<int>::iterator it = number.find(8);
    /* auto it = number.find(8); */
    if(it == number.end())
    {
        cout << "该元素不存在multiset中" << endl;
    }
    else
    {
        cout << "该元素存在multiset中" << *it << endl;
    }

    cout << endl << "multiset的插入操作" << endl;
    number.insert(100);
    display(number);

    cout << endl << endl;
    vector<int> vec = {1, 4, 12, 300, 15, 18};
    number.insert(vec.begin(), vec.end());
    display(number);

    cout << endl << endl;
    number.insert({13, 11, 20, 19});
    display(number);

    cout << endl << "测试bound函数"  << endl;
    auto it2 = number.lower_bound(6);
    auto it3 = number.upper_bound(6);
    cout << "*it2 = " << *it2 << endl;
    cout << "*it3 = " << *it3 << endl;
    while(it2 != it3)
    {
        cout << *it2 << "  ";
        ++it2;
    }
    cout << endl;

    cout << endl << "测试equal_range" << endl;
    std::pair<multiset<int>::iterator, multiset<int>::iterator> ret = 
        number.equal_range(6);
    while(ret.first != ret.second)
    {
        cout << *ret.first << "  ";
        ++ret.first;
    }
    cout << endl;

    cout << endl << "测试erase" << endl;
    it = number.begin();
    ++it;
    ++it;
    number.erase(it);
    display(number);

    cout << endl << "multiset的修改操作" << endl;
    it = number.begin();
    ++it;
    /* *it = 200;//error */
    display(number);

    cout << endl << "multiset的下标访问运算符" << endl;
    /* cout << "number[3] = " << number[3] << endl;//error */
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    void print() const
    {
        cout << "(" << _ix
             << ", " << _iy
             << ")" << endl;
    }
    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);
    friend bool operator<(const Point &lhs, const Point &rhs);
    friend bool operator>(const Point &lhs, const Point &rhs);
    friend struct Compare;

private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "(" << rhs._ix
       << "," << rhs._iy 
       << ")";

    return os;
}

bool operator<(const Point &lhs, const Point &rhs)
{
    cout << "bool operator<(const Point &, const Point &)" << endl;
    if(lhs.getDistance() < rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs._ix < rhs._ix)
        {
            return true;
        }
        else if(lhs._ix == rhs._ix)
        {
            if(lhs._iy < rhs._iy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

bool operator>(const Point &lhs, const Point &rhs)
{
    cout << "bool operator>(const Point &, const Point &)" << endl;
    if(lhs.getDistance() > rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs._ix > rhs._ix)
        {
            return true;
        }
        else if(lhs._ix == rhs._ix)
        {
            if(lhs._iy > rhs._iy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

struct Compare
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        cout << "bool operator()(const T &, const T &)" << endl;
        if(lhs.getDistance() > rhs.getDistance())
        {
            return true;
        }
        else if(lhs.getDistance() == rhs.getDistance())
        {
            if(lhs._ix > rhs._ix)
            {
                return true;
            }
            else if(lhs._ix == rhs._ix)
            {
                if(lhs._iy > rhs._iy)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
};

void test2()
{
    /* multiset<Point> number = { */
    /* multiset<Point, std::greater<Point>> number = { */
    multiset<Point, Compare> number = {
        Point(1, 2),
        Point(3, 4),
        Point(-3, -4),
        Point(-3, -4),
        Point(1, 2),
        Point(1, 0),
        Point(1, 0)
    };
    display(number);
}

int main(int argc, char **argv)
{
    test2();
    return 0;
}

