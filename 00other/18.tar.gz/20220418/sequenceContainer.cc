#include <iostream>
#include <vector>
#include <deque>
#include <list>

using std::cout;
using std::endl;
using std::vector;
using std::deque;
using std::list;

template <typename container>
void display(const container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }

    cout << endl;
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        cout << "Point(int = 0, int = 0)" << endl;
    }

    void print()
    {
        cout << "(" << _ix
             << ", " << _iy
             << ")" << endl;
    }

    ~Point()
    {
        cout << "~Point()" << endl;
    }

private:
    int _ix;
    int _iy;
};
void test00()
{
    vector<Point> vec;
    vec.push_back(Point(1, 2));
    
    vec.emplace_back(1, 2);
    
}
void test()
{
    cout << "sizeof(vector<int>) = " << sizeof(vector<int>) << endl;
    cout << "sizeof(vector<double>) = " << sizeof(vector<double>) << endl;
    vector<int> number = {1, 3, 6, 8, 4, 7, 10, 5};
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << "在vector的尾部进行插入与删除" << endl;
    number.push_back(100);
    number.push_back(200);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;
    number.pop_back();
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    //为什么vector不支持在头部进行插入与删除？O(N)
    
    &number;//error
    &*number.begin();
    int *pdata = number.data();

    cout << endl << "在vector的任意位置插入元素" << endl;
    auto it = number.begin();
    ++it;
    ++it;
    number.insert(it, 30);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << endl;
    cout << "*it = " << *it << endl;
    //插入元素个数过多，导致迭代器失效
    number.insert(it, 20, 40);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl <<endl;
    vector<int> vec = {11, 66, 33, 55, 22};
    //每次使用迭代器的时候，进行重新置位
    it = number.begin();
    ++it;
    ++it;
    number.insert(it, vec.begin(), vec.end());
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << "vector清空元素" << endl;
    number.clear();
    number.shrink_to_fit();
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;
}

void test2()
{
    deque<int> number = {1, 3, 6, 8, 4, 7, 10, 5};
    display(number);

    cout << endl << "在deque的尾部进行插入与删除" << endl;
    number.push_back(100);
    number.push_back(200);
    display(number);
    number.pop_back();
    display(number);

    cout << endl << "在deque的头部进行插入与删除" << endl;
    number.push_front(100);
    number.push_front(200);
    display(number);
    number.pop_front();
    display(number);

    cout << endl << "在deque的任意位置插入元素" << endl;
    auto it = number.begin();
    ++it;
    ++it;
    number.insert(it, 30);
    display(number);

    cout << endl << endl;
    cout << "*it = " << *it << endl;
    number.insert(it, 20, 40);
    display(number);

    cout << endl <<endl;
    vector<int> vec = {11, 66, 33, 55, 22};
    number.insert(it, vec.begin(), vec.end());
    display(number);

    cout << endl << "deque清空元素" << endl;
    number.clear();
    number.shrink_to_fit();
    display(number);
    cout << "number.size() = " << number.size() << endl;
}

void test3()
{
    list<int> number = {1, 3, 6, 8, 4, 7, 10, 5};
    display(number);

    cout << endl << "在list的尾部进行插入与删除" << endl;
    number.push_back(100);
    number.push_back(200);
    display(number);
    number.pop_back();
    display(number);

    cout << endl << "在list的头部进行插入与删除" << endl;
    number.push_front(100);
    number.push_front(200);
    display(number);
    number.pop_front();
    display(number);

    cout << endl << "在list的任意位置插入元素" << endl;
    auto it = number.begin();
    ++it;
    ++it;
    number.insert(it, 30);
    display(number);

    cout << endl << endl;
    cout << "*it = " << *it << endl;
    number.insert(it, 20, 40);
    display(number);

    cout << endl <<endl;
    vector<int> vec = {11, 66, 33, 55, 22};
    number.insert(it, vec.begin(), vec.end());
    display(number);

    cout << endl << "list清空元素" << endl;
    number.clear();
    display(number);
    cout << "number.size() = " << number.size() << endl;
}


int main(int argc, char **argv)
{
    test00();
    cout << endl << "----------测试vector相关操作------" << endl;
    test();

    cout << endl << "----------测试deque相关操作-------" << endl;
    test2();

    cout << endl << "----------测试list相关操作--------" << endl;
    test3();
    return 0;
}
