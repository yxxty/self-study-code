#include <iostream>
#include <vector>

using std::cout;
using std::endl;
using std::vector;

template <typename container>
void display(const container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }

    cout << endl;
}

void test()
{
    vector<int> number = {1, 3, 5, 5, 5, 7, 8};
    display(number);

    for(auto it = number.begin(); it != number.end(); ++it)
    {
        if(5 == *it)
        {
            number.erase(it);
        }
    }
    display(number);
}

void test2()
{
    vector<int> number = {1, 3, 5, 5, 5, 7, 8};
    display(number);

    for(auto it = number.begin(); it != number.end(); )
    {
        if(5 == *it)
        {
            it = number.erase(it);
        }
        else
        {
            ++it;
        }
    }
    display(number);
}

int main(int argc, char **argv)
{
    test2();
    return 0;
}

