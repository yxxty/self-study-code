#include <iostream>
#include <vector>

using std::cout;
using std::endl;
using std::vector;

template <typename container>
void display(const container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }

    cout << endl;
}
void test()
{
    vector<int> number = {1, 3, 6, 8, 4, 7, 10, 5};
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << "在vector的任意位置插入元素" << endl;
    auto it = number.begin();
    ++it;
    ++it;
    number.insert(it, 30);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl << endl;
    //插入元素个数过多，导致迭代器失效
    it = number.begin();
    ++it;
    ++it;
    //size() = t, capacity() = n, count个元素m
    //1、m < n - t,不需要进行扩容
    //2、n - t < m < t,按照2*t进行扩容
    //3、n - t < m, m > t;按照 t + m
    //4、n - t < m, m > n,按照t + m
    number.insert(it, 20, 40);
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

    cout << endl <<endl;
    vector<int> vec = {11, 66, 33, 55, 22};
    //每次使用迭代器的时候，进行重新置位
    it = number.begin();
    ++it;
    ++it;
    number.insert(it, vec.begin(), vec.end());
    display(number);
    cout << "number.size() = " << number.size() << endl;
    cout << "number.capacity() = " << number.capacity() << endl;

}
int main(int argc, char **argv)
{
    test();
    return 0;
}

