#include <iostream>
#include <map>
#include <string>

using std::cout;
using std::endl;
using std::map;
using std::string;

template <typename container>
void display(const container &con)
{
    for(auto &elem : con)
    {
        cout << elem.first << "  "
             << elem.second << endl;
    }

    cout << endl;
}

void test()
{
    map<int, string> number = {
        {1, "hello"},
        {2, "world"},
        std::pair<int, string>(4, "wangdao"),
        std::pair<int, string>(10, "wd"),
        std::make_pair(5, "wuhan"),
        std::make_pair(1, "wuhan"),
        std::make_pair(6, "wuhan"),
    };

    display(number);

    cout << endl << "map的下标访问" << endl;
    cout << "number[1] = " << number[1] << endl;
    cout << "number[7] = " << number[7] << endl;
    display(number);

    number[7] = "hubei";
    &number[7];
    number.operator[](7).operator=("hubei");
    display(number);
}

int main(int argc, char **argv)
{
    test();
    return 0;
}

