 ///
 /// @file    typecast.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-09 10:16:59
 ///
 
#include <iostream>
using std::cout;
using std::endl;
using std::ostream;

class Base
{
public:
	Base(long base = 0)
	: _base(base)
	{	cout << "Base(long)" << endl;	}

	friend ostream & operator<<(ostream & os, const Base & );

	Base(const Base & rhs)
	: _base(rhs._base)
	{
		cout << "Base(const Base & rhs)" << endl;
	}

	Base & operator=(const Base & rhs)
	{
		cout << "Base & operator=(const Base &)" << endl;
		_base = rhs._base;
		return *this;
	}
	

private:
	long _base;
};

ostream & operator<<(ostream & os, const Base & rhs)
{
	os << rhs._base;
	return os;
}

class Derived
: public Base
{
public:
	Derived(long base, long derived)
	: Base(base)
	, _derived(derived)
	{
		cout << "Derived(long,long)" << endl;
	}

	Derived(const Derived & rhs)
	: Base(rhs) //显式调用基类的拷贝构造函数
	, _derived(rhs._derived)
	{
		cout << "Derived(const Derived&)" << endl;
	}

	Derived & operator=(const Derived & rhs)
	{
		Base::operator=(rhs);//显式调用基类的赋值运算符函数
		cout << "Derived & operator=(const Derived&)" << endl;
		_derived = rhs._derived;
		return *this;
	}


	friend ostream & operator<<(ostream & os, const Derived & );
private:
	long _derived;
};
	
ostream & operator<<(ostream & os, const Derived & rhs)
{
	os << Base(rhs) << endl;
	os << rhs._derived;
	return os;
}
 
void test0() 
{
	Derived derived(11, 12);
	cout << "derived:" << derived << endl;
	cout << "111" << endl;

	Derived derived2 = derived;//调用拷贝构造函数
	cout << "222" << endl;

	cout << "derived2:" << derived2 << endl << endl;

#if 1
	Derived derived3(100, 200);
	derived = derived3;//赋值语句
	cout << "derived:" << derived << endl;
#endif
}

 
int main(void)
{
	test0();
	return 0;
}
