 ///
 /// @file    typecast.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-09 10:16:59
 ///
 
#include <iostream>
using std::cout;
using std::endl;
using std::ostream;

//virtual 普通函数不能设计为虚函数
void func()
{}

class Base
{
public:
	//构造函数不能声明为虚函数, 为什么？
	//答:要表现动态多态，有一个前提条件：先创建对象
	//对象创建完毕之后，才能使用虚函数
	//
	//virtual   
	Base(long base)
	: _base(base)
	{	cout << "Base(long)" << endl;	}

	virtual
	void display() const 
	{
		cout << "Base::_base:" << _base << endl;
	}

	//virtual   静态成员函数也不能设计为虚函数
	static int func() 
	{
		
	}


private:
	long _base;
};


class Derived
: public Base
{
public:
	Derived(long base, long derived)
	: Base(base)
	, _derived(derived)
	{
		cout << "Derived(long,long)" << endl;
	}

	//当派生类继承基类时，重定义基类的虚函数
	//同名的虚函数不管在其前面是否有加上virtual关键字
	//它都是一个虚函数
	//virtual
#if 1
	void display() const
	{
		cout << "Derived::_derived:" << _derived << endl;
	}
#endif

private:
	long _derived;
};

//参数是基类指针，但是可以传递派生类对象地址过来
void func(Base * pbase)
{	//同一个指令
	pbase->display();
}
	
 
void test0() 
{
	cout << "sizeof(Base):" << sizeof(Base) << endl;
	cout << "sizeof(Derived):" << sizeof(Derived) << endl;
	Base base(1);

	Derived derived(11, 12);

	func(&base);	//同一指令，不同对象执行不同的行为
	func(&derived);//
} 
 
int main(void)
{
	test0();
	return 0;
}
