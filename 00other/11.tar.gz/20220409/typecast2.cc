 ///
 /// @file    typecast.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-09 10:16:59
 ///
 
#include <iostream>
using std::cout;
using std::endl;
using std::ostream;

class Base
{
public:
	Base(long base)
	: _base(base)
	{	cout << "Base(long)" << endl;	}

	friend ostream & operator<<(ostream & os, const Base & );

private:
	long _base;
};

ostream & operator<<(ostream & os, const Base & rhs)
{
	os << rhs._base;
	return os;
}

class Base2
{
public:
	Base2(long base)
	: _base2(base)
	{	cout << "Base(long)" << endl;	}

	friend ostream & operator<<(ostream & os, const Base2 & );

private:
	long _base2;
};

ostream & operator<<(ostream & os, const Base2 & rhs)
{
	os << rhs._base2;
	return os;
}

class Derived
: public Base
, public Base2
{
public:
	Derived(long base, long base2, long derived)
	: Base(base)
	, Base2(base2)
	, _derived(derived)
	{
		cout << "Derived(long,long)" << endl;
	}

	friend ostream & operator<<(ostream & os, const Derived & );
private:
	long _derived;
};
	
ostream & operator<<(ostream & os, const Derived & rhs)
{
	os << rhs._derived;
	return os;
}
 
void test0() 
{
	Derived derived(1, 2, 3);

	Base * p1 = &derived;

	Base2 * p2 = & derived;

	Derived * p3 = &derived;

	cout << "p1:" << p1 << endl
		 << "p2:" << p2 << endl
		 << "p3:" << p3 << endl;
} 
 
int main(void)
{
	test0();
	return 0;
}
