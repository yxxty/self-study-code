 ///
 /// @file    typecast.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-09 10:16:59
 ///
 
#include <iostream>
using std::cout;
using std::endl;
using std::ostream;

class Base
{
public:
	Base(long base)
	: _base(base)
	{	cout << "Base(long)" << endl;	}

	friend ostream & operator<<(ostream & os, const Base & );

private:
	long _base;
};

ostream & operator<<(ostream & os, const Base & rhs)
{
	os << rhs._base;
	return os;
}

class Derived
: public Base
{
public:
	Derived(long base, long derived)
	: Base(base)
	, _derived(derived)
	{
		cout << "Derived(long,long)" << endl;
	}

	friend ostream & operator<<(ostream & os, const Derived & );
private:
	long _derived;
};
	
ostream & operator<<(ostream & os, const Derived & rhs)
{
	os << rhs._derived;
	return os;
}
 
void test0() 
{
	Base base(1);
	cout << "base:" << base << endl;
	Derived derived(11, 12);
	cout << "derived:" << derived << endl;

	//对象间的转换
	//用派生类对象赋值给基类对象
	base = derived;//ok, Base & operator=(const Base &)
	//derived = base;//error, Derived & operator=(const Derived&)
 
	cout << "base:" << base << endl;

	Base * pbase = &base;
	//基类指针可以指向派生类对象
	pbase = &derived;

	//派生类指针不能指向基类对象
	//Derived * pderived = &base;//error
	//pderived = &derived;
	
	//可以将一个基类引用绑定到派生类对象
	Base & ref = derived;//ok
	//Derived & ref2 = base;//error
} 
 
int main(void)
{
	test0();
	return 0;
}
