#ifndef __TIMERFD_H__
#define __TIMERFD_H__

#include <functional>

using std::function;

class TimerFd
{
    using TimerFdCallback = function<void()>;
public:
    TimerFd(int initsec, int periodicsec, TimerFdCallback &&cb);
    ~TimerFd();
    void start();
    void stop();

    void handleRead();
private:
    int createTimerFd();
    void setTimerFd(int init, int periodic);
private:
    int _timerfd;
    int _initsec;
    int _periodicsec;
    TimerFdCallback _cb;
    bool _isStarted;

};

#endif
