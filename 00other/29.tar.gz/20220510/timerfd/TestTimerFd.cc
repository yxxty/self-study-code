#include "TimerFd.h"
#include "Thread.h"
#include <unistd.h>
#include <iostream>

using std::cout;
using std::endl;

void process()
{
    cout << "The process is running" << endl;
}

void test()
{
    TimerFd tf(1, 6, process);

    Thread th(std::bind(&TimerFd::start, &tf));//子线程
    th.start();

    sleep(20);


    tf.stop();
    th.join();
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

