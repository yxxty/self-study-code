#ifndef __TASK_H__
#define __TASK_H__

#include <functional>

using Task = std::function<void()>;

#endif
