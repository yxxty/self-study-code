#include <iostream>
#include <set>
#include <map>
#include <utility>
#include <string>


using std::cout;
using std::endl;
using std::set;
using std::map;
using std::pair;
using std::string;

void test()
{
    //初始化
    /* int arr[10] = {1, 6, 9, 3, 7, 3, 8, 10, 5, 6}; */
    /* set<int> number(arr, arr + 10);//左闭右开[arr, arr +10) */
    set<int> number = {1, 6, 9, 3, 7, 3, 8, 10, 5, 6};

    //遍历
    for(auto &elem : number)
    {
        cout << elem << "  ";
    }
    cout << endl;

    //迭代器可以看成是一种指针
    set<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
    }
    cout << endl;

    cout << endl << "set的查找"  << endl;
    size_t cnt1 = number.count(9);
    size_t cnt2 = number.count(4);
    cout << "cnt1 = " << cnt1 << endl;
    cout << "cnt2 = " << cnt2 << endl;

    cout << endl;
    /* set<int>::iterator it2 = number.find(9); */
    set<int>::iterator it2 = number.find(4);
    if(it2 == number.end())
    {
        cout << "该元素不在set中" << endl;
    }
    else
    {
        cout << "该元素存在set中: " << *it2 << endl;
    }

    cout << endl << "set的插入操作"  << endl;

    /* pair<set<int>::iterator, bool> ret = number.insert(10); */
    auto ret = number.insert(10);
    if(ret.second)
    {
        cout << "该值插入成功" << *ret.first << endl;
    }
    else
    {
        cout << "该元素插入失败，该元素存在set中" << endl;
    }
    for(auto &elem : number)
    {
        cout << elem << "  ";
    }
    cout << endl;

    int arr1[5] = {7, 4, 11, 2, 8};
    number.insert(arr1, arr1 + 5);
    for(auto &elem : number)
    {
        cout << elem << "  ";
    }
    cout << endl;

    //set不支持下标访问
    cout << endl << "set下标访问" << endl;
    /* cout << "number[5] = " << number[5] << endl; */

    cout << endl;
    auto it3 = number.begin();
    cout << "*it3 = " << *it3 << endl;
    /* *it3 = 100;//error,不支持修改 */

}

void test00()
{
    pair<int, string> number(1, "hello");
    cout << number.first << "    "<< number.second << endl;
}

void test2()
{
    map<int, string> number = {
        {1, "hello"},
        {3, "world"},
        {6, "wuhan"},
        {2, "beijing"},
        pair<int, string>(9, "nanjing"),
        pair<int, string>(4, "nanjing"),
        pair<int, string>(2, "beijing"),
        pair<int, string>(2, "dongjing")
    };

    for(auto &elem : number)
    {
        cout << elem.first << "  " << elem.second << endl;
    }

    cout << endl << endl;
    map<int, string>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout << it->first << "  " << it->second << endl;
    }

    cout << endl << "map的查找"  << endl;
    size_t cnt1 = number.count(10);
    size_t cnt2 = number.count(9);
    cout << "cnt1 = " << cnt1 << endl;
    cout << "cnt2 = " << cnt2 << endl;

    cout << endl;
    /* set<int>::iterator it2 = number.find(9); */
    map<int, string>::iterator it2 = number.find(4);
    if(it2 == number.end())
    {
        cout << "该元素不在map中" << endl;
    }
    else
    {
        cout << "该元素存在map中: " 
            << it2->first << "  "
            << it2->second << endl;
    }

    cout << endl << "set的插入操作"  << endl;
    /* pair<map<int,string>::iterator, bool> ret = */ 
    /*     number.insert(pair<int, string>(5, "hubei")); */
    auto ret = number.insert({5, "hubei"});
    if(ret.second)
    {
        cout << "插入成功 : " << ret.first->first
             << "   " << ret.first->second << endl;
    }
    else
    {
        cout << "插入失败，该元素存在map中" << endl;
    }

    cout << endl << "map的下标访问" << endl;
    cout << "number[1] = " << number[1] << endl;
    cout << "number[7] = " << number[7] << endl;

    cout << endl;
    for(auto &elem : number)
    {
        cout << elem.first << "  " << elem.second << endl;
    }

    number[7] = "wangdao";
    cout << endl;
    for(auto &elem : number)
    {
        cout << elem.first << "  " << elem.second << endl;
    }

    cout << endl;
    /* number[1] = "wangdao"; */
    number.operator[](1).operator=("wangdao");
    cout << endl;
    for(auto &elem : number)
    {
        cout << elem.first << "  " << elem.second << endl;
    }
}

void test3()
{
    map<string, string> number = {
        {"010", "北京"},
        {"020", "天津"},
    };

    cout << "number[\"010\"] = " << number["010"] << endl;
    cout << "number[\"030\"] = " << number["030"] << endl;
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

