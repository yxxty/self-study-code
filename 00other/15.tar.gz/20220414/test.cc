#include <iostream>

using std::cout;
using std::endl;

int main(int argc, char **argv)
{
    int *pInt = new int(10);

    delete pInt;

    const char *pstr = "helloworld";

    delete pstr;
    if(pInt)//if(pInt != nullptr)
    {

    }

    ifstream ifs("hello.txt");
    if(ifs)//ifstream     operator bool(){:}
    {

    }
    return 0;
}

