#include <iostream>
#include <memory>
#include <vector>

using std::cout;
using std::endl;
using std::unique_ptr;
using std::vector;

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        cout << "Point(int = 0, int = 0)" << endl;
    }

    void print()
    {
        cout << "(" << _ix
             << ", " << _iy
             << ")" << endl;
    }

    ~Point()
    {
        cout << "~Point()" << endl;
    }

private:
    int _ix;
    int _iy;
};

void test()
{
    int *pInt = new int(10);
    unique_ptr<int> up(pInt);
    cout << "*up = " << *up << endl;
    cout << "pInt = " << pInt << endl;
    cout << "up.get() = " << up.get() << endl;

    cout << endl;
    /* unique_ptr<int> up2(up);//error */
    /* unique_ptr<int> up2 = up;//error */

    cout << endl;
    unique_ptr<int> up3(new int(20));
    /* up3 = up;//error */

    vector<unique_ptr<Point>> vec;
    unique_ptr<Point> up4(new Point(3, 4));
    /* vec.push_back(std::move(up4)); */
    vec.push_back(unique_ptr<Point>(new Point(3, 4)));
    
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

