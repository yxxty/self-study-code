#include <iostream>
#include <memory>
#include <string>

using std::cout;
using std::endl;
using std::unique_ptr;
using std::shared_ptr;
using std::string;

struct FILECloser
{
    void operator()(FILE *fp) const
    {
        if(fp)
        {
            fclose(fp);
        }
    }
};

void test()
{
    string msg = "hello,world\n";
    unique_ptr<FILE, FILECloser> up(fopen("wd.txt", "a+"));
    fwrite(msg.c_str(), 1, msg.size(), up.get());
    /* fclose(up.get());//error */
}

void test2()
{
    string msg = "hello,world\n";
    shared_ptr<FILE> sp(fopen("hello.txt", "a+"), FILECloser());
    fwrite(msg.c_str(), 1, msg.size(), sp.get());
    /* fclose(up.get());//error */
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

