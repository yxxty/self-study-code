#include <iostream>
#include <memory>
#include <vector>

using std::cout;
using std::endl;
using std::shared_ptr;
using std::vector;

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        cout << "Point(int = 0, int = 0)" << endl;
    }

    void print()
    {
        cout << "(" << _ix
             << ", " << _iy
             << ")" << endl;
    }

    ~Point()
    {
        cout << "~Point()" << endl;
    }

private:
    int _ix;
    int _iy;
};

void test()
{
    int *pInt = new int(10);
    shared_ptr<int> sp(pInt);
    cout << "*sp = " << *sp << endl;
    cout << "pInt = " << pInt << endl;
    cout << "sp.get() = " << sp.get() << endl;
    cout << "sp.use_count() = " << sp.use_count() << endl;

    cout << endl;
    shared_ptr<int> sp2(sp);//ok
    cout << "*sp2 = " << *sp2 << endl;
    cout << "*sp = " << *sp << endl;
    cout << "sp2.use_count() = " << sp2.use_count() << endl;
    cout << "sp.use_count() = " << sp.use_count() << endl;

    cout << endl;
    shared_ptr<int> sp3(new int(20));
    cout << "*sp3 = " << *sp3 << endl;
    cout << "sp3.use_count() = " << sp3.use_count() << endl;

    cout << "执行赋值操作后" << endl;
    sp3 = sp;//ok
    cout << "*sp3 = " << *sp3 << endl;
    cout << "*sp2 = " << *sp2 << endl;
    cout << "*sp = " << *sp << endl;
    cout << "sp3.use_count() = " << sp3.use_count() << endl;
    cout << "sp2.use_count() = " << sp2.use_count() << endl;
    cout << "sp.use_count() = " << sp.use_count() << endl;

    cout << endl << endl;
    vector<shared_ptr<Point>> vec;
    shared_ptr<Point> sp4(new Point(3, 4));
    vec.push_back(sp4);
    /* vec.push_back(shared_ptr<Point>(new Point(3, 4))); */
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

