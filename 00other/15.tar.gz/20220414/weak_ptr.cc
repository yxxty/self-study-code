#include <iostream>
#include <memory>

using std::cout;
using std::endl;
using std::shared_ptr;
using std::weak_ptr;

void test()
{
    weak_ptr<int> wp;
    {
        shared_ptr<int> sp(new int(10));
        wp = sp;
        cout << "sp.use_count() = " << sp.use_count() << endl;
        cout << "wp.use_count() = " << wp.use_count() << endl;

        bool flag = wp.expired();
        cout << "flag = " << flag << endl;
        shared_ptr<int> sp2 = wp.lock();
        if(sp2)
        {
            cout << "提升成功" << endl;
            cout <<"*sp2 = " << *sp2 << endl;
        }
        else
        {
            cout << "提升失败" << endl;
        }
    }
        
    cout << endl;
    bool flag = wp.expired();
    cout << "flag = " << flag << endl;

    shared_ptr<int> sp2 = wp.lock();
    if(sp2)
    {
        cout << "提升成功" << endl;
        cout <<"*sp2 = " << *sp2 << endl;
    }
    else
    {
        cout << "提升失败" << endl;
    }
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

