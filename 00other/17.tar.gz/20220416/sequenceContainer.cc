#include <iostream>
#include <vector>
#include <deque>
#include <list>

using std::cout;
using std::endl;
using std::vector;
using std::deque;
using std::list;

void test()
{
    /* vector<int> number;//1、创建空对象 */
    /* vector<int> number(10);//2、count个value */
    /* int arr[10] = {1, 3, 5, 7, 9, 8, 6, 4, 2, 10}; */
    /* vector<int> number(arr, arr + 10);//[arr, arr + 10),3、迭代器范围 */
    vector<int> number = {1, 4, 7, 9, 3, 5, 8, 9, 12};//4、大括号

    //遍历
    for(size_t idx = 0; idx != number.size();++idx)
    {
        cout << number[idx] << "  ";
    }
    cout << endl;

    vector<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
    }
    cout << endl;

    auto ct = number.begin();
    for(; ct != number.end(); ++ct)
    {
        cout << *ct << "  ";
    }
    cout << endl;

    for(auto &elem : number)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test2()
{
    /* deque<int> number;//1、创建空对象 */
    /* deque<int> number(10, 2);//2、count个value */
    /* int arr[10] = {1, 3, 5, 7, 9, 8, 6, 4, 2, 10}; */
    /* deque<int> number(arr, arr + 10);//[arr, arr + 10),3、迭代器范围 */
    deque<int> number = {1, 4, 7, 9, 3, 5, 8, 9, 12};//4、大括号

    //遍历
    for(size_t idx = 0; idx != number.size();++idx)
    {
        cout << number[idx] << "  ";
    }
    cout << endl;

    deque<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
    }
    cout << endl;

    auto ct = number.begin();
    for(; ct != number.end(); ++ct)
    {
        cout << *ct << "  ";
    }
    cout << endl;

    for(auto &elem : number)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test3()
{
    /* list<int> number;//1、创建空对象 */
    /* list<int> number(10, 2);//2、count个value */
    /* int arr[10] = {1, 3, 5, 7, 9, 8, 6, 4, 2, 10}; */
    /* list<int> number(arr, arr + 10);//[arr, arr + 10),3、迭代器范围 */
    list<int> number = {1, 4, 7, 9, 3, 5, 8, 9, 12};//4、大括号

    //遍历
#if 0
    //list是不支持下标访问的
    for(size_t idx = 0; idx != number.size();++idx)
    {
        cout << number[idx] << "  ";
    }
    cout << endl;
#endif

    list<int>::iterator it;
    for(it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
    }
    cout << endl;

    auto ct = number.begin();
    for(; ct != number.end(); ++ct)
    {
        cout << *ct << "  ";
    }
    cout << endl;

    for(auto &elem : number)
    {
        cout << elem << "  ";
    }
    cout << endl;
}
int main(int argc, char **argv)
{
    test3();
    return 0;
}

