#include <iostream>
#include <vector>
#include <deque>
#include <list>

using std::cout;
using std::endl;
using std::vector;
using std::deque;
using std::list;

template <typename container>
void display(const container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }
    cout << endl;
}

void test()
{
    cout << "sizeof(vector<int>) = " << sizeof(vector<int>) << endl;
    cout << "sizeof(vector<double>) = " << sizeof(vector<double>) << endl;
    vector<int> number = {1, 3, 6, 8, 4, 7, 10, 5};
    display(number);

    cout << endl << "在vector的尾部进行插入与删除" << endl;
    number.push_back(100);
    number.push_back(200);
    display(number);
    number.pop_back();
    display(number);
}

void test2()
{
    deque<int> number = {1, 3, 6, 8, 4, 7, 10, 5};
    display(number);

    cout << endl << "在deque的尾部进行插入与删除" << endl;
    number.push_back(100);
    number.push_back(200);
    display(number);
    number.pop_back();
    display(number);

    cout << endl << "在deque的头部进行插入与删除" << endl;
    number.push_front(100);
    number.push_front(200);
    display(number);
    number.pop_front();
    display(number);
}

void test3()
{
    list<int> number = {1, 3, 6, 8, 4, 7, 10, 5};
    display(number);

    cout << endl << "在list的尾部进行插入与删除" << endl;
    number.push_back(100);
    number.push_back(200);
    display(number);
    number.pop_back();
    display(number);

    cout << endl << "在list的头部进行插入与删除" << endl;
    number.push_front(100);
    number.push_front(200);
    display(number);
    number.pop_front();
    display(number);
}


int main(int argc, char **argv)
{
    test();
    cout << endl << endl;

    test2();
    cout << endl << endl;

    test3();
    return 0;
}

