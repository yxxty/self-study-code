#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>

using std::cout;
using std::endl;
using std::for_each;
using std::vector;
using std::ostream_iterator;
using std::copy;

void print(int &val)
{
    ++val;
    cout << val << "  ";
}
void test()
{
    vector<int> number = {1, 5, 9, 3, 8, 6};
    /* for_each(number.begin(), number.end(), print); */
    //匿名函数,lambda表达式,C++11提出来的
    for_each(number.begin(), number.end(), [](int &val){
             ++val;
             cout << val << "  ";

             });
    cout << endl;
    copy(number.begin(), number.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;
}

void test2()
{
    vector<int> number = {1, 5, 9, 3, 8, 6};
    size_t cnt1 = count(number.begin(), number.end(), 9);
    cout << "cnt1 = " << cnt1 << endl;

    auto it = find(number.begin(), number.end(), 8);

}
int main(int argc, char **argv)
{
    test();
    return 0;
}

