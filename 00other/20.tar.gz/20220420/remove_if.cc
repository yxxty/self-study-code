#include <iostream>
#include <algorithm>
#include <vector>
#include <iterator>

using std::cout;
using std::endl;
using std::remove_if;
using std::vector;
using std::ostream_iterator;

bool func(int value)
{
    return value > 5;
}

void test()
{
    vector<int> number = {1, 3, 6, 5, 4, 8, 9, 10};
    auto it = remove_if(number.begin(), number.end(), bind2nd(std::greater<int>(), 5));
    /* auto it = remove_if(number.begin(), number.end(), bind1st(std::less<int>(), 5)); */
    
    /* auto it = remove_if(number.begin(), number.end(), [](int value){ */
    /*                     return value > 5; */
    /*                     }); */

    /* auto it = remove_if(number.begin(), number.end(), func); */
    number.erase(it, number.end());
    copy(number.begin(), number.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;
}

void test2()
{
    vector<int> number;
    number.push_back(1);
    /* cout << "number.size() = " << number.size() << endl; */
    /* cout << "number.capacity() = " << number.capacity() << endl; */

    bool flag = true;
    for(auto it = number.begin(); it != number.end(); ++it)
    {
        cout << *it << "  ";
        if(flag)
        {
            number.push_back(2);//底层已经发生了扩容操作
            /* cout << "number.size() = " << number.size() << endl; */
            /* cout << "number.capacity() = " << number.capacity() << endl; */
            flag = false;

            it = number.begin();
        }
    }
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

