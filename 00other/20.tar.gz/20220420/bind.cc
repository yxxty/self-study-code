#include <iostream>
#include <functional>

using std::cout;
using std::endl;
using std::bind;

int add(int x, int y)
{
    cout << "int add(int, int)" << endl;
    return x + y;
}

class Test
{
public:
    int add(int x, int y)
    {
        cout << "int Test::add(int, int)" << endl;
        return x + y;
    }
};

void test()
{
    //add   int(int, int),函数也是有类型的,函数的类型
    //可以通过函数返回类型，加上参数类型确定
    //int()
    auto f = bind(add, 1, 2);
    cout << "f() = " << f() << endl;

    Test tst;
    auto f1 = bind(&Test::add, tst, 20, 30);
    cout << "f1() = " << f1() << endl;
}

int func1()
{
    return 10;
}

int func2()
{
    return 20;
}

int func3(int x)
{
    return x;
}

void test2()
{
    typedef int (*pFunc)();
    pFunc pf = &func1;//注册回调函数,钩子函数
    //...
    cout << "pf() = " << pf() << endl;//执行回调函数

    pf = func2;
    cout << "pf() = " << pf() << endl;

    /* pFunc = func3;//error */
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

