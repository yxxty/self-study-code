#include <iostream>
#include <vector>
#include <algorithm>
#include <functional>

using std::cout;
using std::endl;
using std::vector;
using std::for_each;

class Number
{
public:
    Number(int data = 0)
    : _data(data)
    {

    }

    void print() const
    {
        cout << _data << "  ";
    }

    bool isEven()
    {
        return (0 == (_data % 2));
    }

    bool isPrimer()
    {
        if(1 == _data)
        {
            return false;
        }
        for(int idx = 2; idx != _data/2; ++idx)
        {
            if(_data%idx == 0)
            {
                return false;
            }
        }

        return true;
    }

    ~Number()
    {

    }
private:
    int _data;
};

void test()
{
    vector<Number> vec;

    for(size_t idx = 1; idx != 30; ++idx)
    {
        vec.push_back(Number(idx));
    }

    for_each(vec.begin(), vec.end(), std::mem_fn(&Number::print));

}
int main(int argc, char **argv)
{
    test();
    return 0;
}

