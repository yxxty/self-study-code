#include <iostream>
#include <functional>

using std::cout;
using std::endl;
using std::bind;

int add(int x, int y)
{
    cout << "int add(int, int)" << endl;
    return x + y;
}

class Test
{
public:
    int add(int x, int y)
    {
        cout << "int Test::add(int, int)" << endl;
        return x + y;
    }

    int data = 200;//C++11
};

void test()
{
    //std::function + bind可以实现多态
    //add   int(int, int),函数也是有类型的,函数的类型
    //可以通过函数返回类型，加上参数类型确定
    //int()
    /* auto f = bind(add, 1, 2); */
    //std::function称为函数的容器
    std::function<int()> f = bind(add, 1, 2);
    cout << "f() = " << f() << endl;

    Test tst;
    /* auto f1 = bind(&Test::add, tst, 20, 30); */
    std::function<int()> f1 = bind(&Test::add, tst, 20, 30);
    cout << "f1() = " << f1() << endl;

    //int(int)
    /* auto f2 = bind(add, 1, std::placeholders::_1);//占位符 */
    std::function<int(int)> f2 = bind(add, 1, std::placeholders::_1);//占位符
    /* cout << "f2(10, 20) = " << f2(10, 20) << endl; */
    cout << "f2(10) = " << f2(10) << endl;

    //bind还可以绑定到数据成员上来
    f1 = bind(&Test::data, &tst);//int data = 200;
    cout << "f1() = " << f1() << endl;
}

int func1()
{
    return 10;
}

int func2()
{
    return 20;
}

int func3(int x)
{
    return x;
}

void test2()
{
    typedef int (*pFunc)();
    pFunc pf = &func1;//注册回调函数,钩子函数
    //...
    cout << "pf() = " << pf() << endl;//执行回调函数

    pf = func2;
    cout << "pf() = " << pf() << endl;

    /* pFunc = func3;//error */
}

void func4(int x1, int x2, int x3, const int &x4, int x5)
{
    cout << "x1 = " << x1
         << ", x2 = " << x2
         << ", x3 = " << x3
         << ", x4 = " << x4
         << ", x5 = " << x5 << endl;
}

void test3()
{
    //占位符本身占据形参的位置
    //占位符中的数字代表的是实参的位置
    //bind采用的值传递
    //std::cref = const reference，引用的包装器
   int number = 100; 
   auto f = bind(func4, 10, std::placeholders::_2, 
                 std::placeholders::_1,std::cref( number), number);
   number = 200;
   f(1, 8, 9, 56, 123);//实参没有使用的直接丢弃
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

