#include "TaskQueue.h"

TaskQueue::TaskQueue(size_t sz)
: _queSize(sz)
, _que()
, _mutex()
, _notFull(_mutex)
, _notEmpty(_mutex)
{

}

TaskQueue::~TaskQueue()
{

}

bool TaskQueue::empty() const
{
    return _que.size() == 0;
}

bool TaskQueue::full() const
{
    return _queSize == _que.size();
}

void TaskQueue::push(ElemType ptask)
{
    //RAII的思想
    MutexLockGuard autoLock(_mutex);//利用栈对象的生命周期管理资源
    while(full())
    {
        _notFull.wait();
    }
    //else return;

    _que.push(ptask);

    _notEmpty.notify();

    /* _mutex.unlock(); */
}

ElemType TaskQueue::pop()
{
    MutexLockGuard autoLock(_mutex);//利用栈对象的生命周期管理资源
    while(empty())
    {
        _notEmpty.wait();
    }

    ElemType number = _que.front();
    _que.pop();

    _notFull.notify();

    return number;

}
