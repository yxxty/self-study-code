#include "ThreadPool.h"
#include "WorkThread.h"
#include "Task.h"

ThreadPool::ThreadPool(size_t threadNum, size_t queSize)
: _threadNum(threadNum)
, _queSize(queSize)
, _taskQue(queSize) 
, _isExit(false)
{
    _threads.reserve(threadNum);
}

ThreadPool::~ThreadPool()
{
    if(!_isExit)
    {
        stop();
    }

}

void ThreadPool::addTask(Task *ptask)
{
    if(ptask)
    {
        _taskQue.push(ptask);
    }
}

Task *ThreadPool::getTask()
{
    return _taskQue.pop();
}

void ThreadPool::threadFunc()
{
    Task *ptask = getTask();
    while(ptask)
    {
        ptask->process();
    }
}

void ThreadPool::start()
{
    for(size_t idx = 0; idx != _threadNum; ++idx)
    {
        unique_ptr<Thread> pthread(new WorkThread(*this));
        _threads.push_back(std::move(pthread));
    }

    for(auto &th : _threads)
    {
        th->start();//启动WorkThread
    }
}

void ThreadPool::stop()
{
    _isExit = true;
    for(auto &th : _threads)
    {
        th->join();
    }
}


