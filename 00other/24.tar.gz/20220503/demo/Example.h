#ifndef __EXAMPLE_H__
#define __EXAMPLE_H__

#include "NonCopyable.h"


class Example
: NonCopyable
{
public:
    Example();
    ~Example();

private:

};

#endif
