#include "Example.h"
#include <iostream>

using std::cout;
using std::endl;

int main(int argc, char **argv)
{
    Example ex;//创建对象是ok

    Example ex2 = ex;//error

    Example ex3;
    ex3 = ex;//error
    return 0;
}

