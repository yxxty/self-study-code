#ifndef __SOCKETIO_H__
#define __SOCKETIO_H__

//数据的接收与发送
class SocketIO
{
public:
    SocketIO(int fd);

    int readn(char *buf, int len);
    int writen(const char *buf, int len);
    int readLine(char *buf, int maxLen);

private:
    int _fd;

};

#endif
