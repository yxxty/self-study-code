#ifndef __ACCEPTOR_H__
#define __ACCEPTOR_H__

#include "InetAddress.h"
#include "Socket.h"

class Acceptor
{
public:
    Acceptor(const string &ip, unsigned short port);
    void ready();
    void setReuseAddr();
    void setReusePort();
    void bind();
    void listen();
    int accept();

private:
    Socket _listenSock;
    InetAddress _servAddr;
};

#endif
