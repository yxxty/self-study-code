#ifndef __TCPCONNECTION_H__
#define __TCPCONNECTION_H__

#include "InetAddress.h"
#include "Socket.h"
#include "SocketIO.h"

class TcpConnection
{
public:
    TcpConnection(int fd);
    void send(const string &msg);
    string receive();

    string toString();

private:
    InetAddress getLocalAddr();
    InetAddress getPeerAddr();

private:
    Socket _clientSock;
    SocketIO _sockIO;
    InetAddress _localAddr;
    InetAddress _peerAddr;


};

#endif
