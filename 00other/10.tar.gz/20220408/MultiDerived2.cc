 ///
 /// @file    MultiDerived.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-08 17:27:43
 ///
 
#include <iostream>
using std::cout;
using std::endl;


class A
{
public:
	A() {	cout << "A()" << endl;	}
	~A() {	cout << "~A()" << endl;	}
	void print() const
	{	cout << "A::_a :" << _a << endl;	}
private:
	long _a;
};

class B
{
public:
	B() {	cout << "B()" << endl;	}
	~B() {	cout << "~B()" << endl;	}
	void print() const
	{	cout << "B::_b :" << _b << endl;	}
private:
	long _b;
};
 
class C
{
public:
	C() {	cout << "C()" << endl;	}
	~C() {	cout << "~C()" << endl;	}

	void print() const
	{	cout << "C::_c " << _c << endl;	}
private:
	long _c;
};


//多重继承时，记得要在每一个基类的前面加上
//访问权限，否则就是采用了私有继承
//
//多重继承时，基类被初始化的顺序只与其被继承时的顺序有关，
//而与其在派生类构造函数的出是表达式中的顺序无关
class D
: public B
, public A
, public C
{
public:
	D()
	: B()
	, A()
	, C()
	{	cout << "D()" << endl;}

	~D() {	cout << "~D()" << endl;}
private:
	long _id;
};

void test0() 
{
	cout << "sizeof(D):" << sizeof(D) << endl;
	D d;
	//成员名访问冲突的二义性
	//解决方案：用类的作用域限定符
	//d.print();
	d.A::print();
	d.B::print();
	d.C::print();
} 
 
int main(void)
{
	test0();
	return 0;
}
