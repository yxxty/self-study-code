 ///
 /// @file    Point3D.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-08 15:08:45
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Point
{
public:
	Point(int ix = 0, int iy = 0)
	: _ix(ix)
	, _iy(iy)
	{	cout << "Point(int,int)" << endl;	}

	void print() const 
	{
		cout << "(" << _ix
			 << "," << _iy
			 << ")" << endl;
	}
	int getY() const {	return _iy;	}
//该成员只能在派生类内部进行访问
protected:
	int getX() const {	return _ix;	}

protected:	
	int _ix;
private:// 私有成员只能在本类内部访问
	int _iy;
};

class Point3D
: protected Point//保护继承
{
public:
	Point3D(int ix, int iy, int iz)
	: Point(ix, iy)
	, _iz(iz)
	{	cout << "Point3D(int,int,int)" << endl;}

	void display() const
	{
		print();//protected
		cout << "(" << _ix	//protected
			 //<< "," << _iy// 对于基类的私有成员，无论采用什么继承方式，都是不能访问
			 << "," << getY() //protected
			 << "," << _iz
			 << ")" << endl;
	}

private:
	int _iz;
};
 
class Point4D
: public Point3D
{
public:

	void show() const
	{
		//protected
		cout << "(" << _ix << endl;
	}

	int _im;
};


void test0() 
{
	//派生类对象不能访问非公有的成员
	//派生类对象只能访问公有继承的基类的公有成员
	//
	Point3D pt(1, 2, 3);
	//pt.getX();//error
	pt.print();//基类的public成员,
	pt.display();
	//pt._ix;//error
	//pt._iy;//error
	//pt._iz;//error
} 
 
int main(void)
{
	test0();
	return 0;
}
