 ///
 /// @file    MultiDerived.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-08 17:27:43
 ///
 
#include <iostream>
using std::cout;
using std::endl;


class A
{
public:
	A() {	cout << "A()" << endl;	}
	~A() {	cout << "~A()" << endl;	}
	void print() const
	{	
		cout << "A::print()" << endl;
		//cout << "A::_a :" << _a << endl;	
	}
private:
	long _a;
};

//中间层次B和C虚拟继承自A，就可以解决
class B
: virtual public A
//: public A
{
public:
	B() {	cout << "B()" << endl;	}
	~B() {	cout << "~B()" << endl;	}
	void printB() const
	{	cout << "B::_b :" << _b << endl;	}
private:
	long _b;
};
 
class C
: virtual public A
//: public A
{
public:
	C() {	cout << "C()" << endl;	}
	~C() {	cout << "~C()" << endl;	}

	void printC() const
	{	cout << "C::_c " << _c << endl;	}
private:
	long _c;
};


class D
: public B
, public C
{
public:
	D()
	: B()
	, C()
	{	cout << "D()" << endl;}

	~D() {	cout << "~D()" << endl;}
private:
	long _id;
};

void test0() 
{
	cout << "sizeof(D):" << sizeof(D) << endl;
	D d;
	//存储布局冲突的二义性
	//解决方案：采用虚拟继承
	d.print();
	d.A::print();
	d.B::print();
	d.C::print();
} 
 
int main(void)
{
	test0();
	return 0;
}
