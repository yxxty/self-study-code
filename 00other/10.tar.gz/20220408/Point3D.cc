 ///
 /// @file    Point3D.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-08 15:08:45
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Point
{
public:
	Point(int ix = 0, int iy = 0)
	: _ix(ix)
	, _iy(iy)
	{	cout << "Point(int,int)" << endl;	}

	void print() const 
	{
		cout << "(" << _ix
			 << "," << _iy
			 << ")" << endl;
	}

protected:	
	int _ix;
private:
	int _iy;
};

class Point3D
: Point //默认的继承方式是私有继承
{
public:
	Point3D(int ix, int iy, int iz)
	: Point(ix, iy)
	, _iz(iz)
	{	cout << "Point3D(int,int,int)" << endl;}

	void display() const
	{
		print();//private
		cout << "(" << _ix//private
	//		 << "," << _iy //无法访问
			 << "," << _iz
			 << ")" << endl;
	}

private:
	int _iz;
};

class Point4D
: public Point3D
{
public:

	void show() const
	{
		//
		cout << "(" << _ix << endl;//无法访问到的
	}

	int _im;
};

 
void test0() 
{
	Point3D pt(1, 2, 3);
	//pt.print();//private, error
	pt.display();
	//pt._ix;
	//pt._iy;
	//pt._iz;
} 
 
int main(void)
{
	test0();
	return 0;
}
