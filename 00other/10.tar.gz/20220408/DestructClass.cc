 ///
 /// @file    DerivedClassConstruct.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-08 16:11:03
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Base
{
public:
	Base(): _ibase(0) { cout << "Base()" << endl;	}

	Base(int x)
	: _ibase(x)
	{	cout << "Base()" << endl;	}

	~Base() {	cout << "~Base()" << endl;	}

	void print() const
	{	cout << "Base::_ibase:" << _ibase << endl;	}	

private:
	int _ibase;
};

class Example
{
public:
	Example(int x = 0) : _e(x)
	{	cout << "Example()" << endl;	}

	~Example() {	cout << "~Example()" << endl;	}

private:
	int _e;
};

class Derived
: public Base //接口继承
{
public:
	Derived()
	: Base() 
	, _iderived(1)
	{	cout << "Derived()" << endl;	}

//因为Base的构造函数是public的, 
//并不是因为派生类继承了基类的构造函数
	Derived(int x, int y)
	: Base(x)  
	, _example()  //类对象成员默认情况下会调用默认构造函数进行初始化
	, _iderived(y)
	{
		cout << "Derived(int,int)" << endl;
	}

	Derived(int x, int y, int z)
	: Base(x)  //基类部分的初始化
	, _example(y) //类对象成员的初始化
	, _iderived(z)
	{	cout << "Derived(int,int,int)" << endl;	}

//当派生类析构函数被调用之后，会自动执行基类部分的析构函数
	~Derived() {	cout << "~Derived()" << endl;}

	void display() const
	{
		print();
		cout << "Derived::_iderived " << _iderived << endl;
	}

private:
	Example _example;
	int _iderived;
};

void test1()
{
	Derived d1(10, 100);
	d1.print();
	d1.display();

	//Base b1(1);//Base(int)
	//b1.print();
}
 
void test0() 
{
	Derived d1;
	d1.print();
	d1.display();
} 
 
int main(void)
{
	/* test0(); */
	test1();
	return 0;
}
