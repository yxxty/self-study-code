 ///
 /// @file    MultiDerived.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-08 17:27:43
 ///
 
#include <iostream>
using std::cout;
using std::endl;


class A
{
public:
	A() {	cout << "A()" << endl;	}
	~A() {	cout << "~A()" << endl;	}
	void print() const
	{	cout << "A::_a :" << _a << endl;	}
private:
	long _a;
};

class B
{
public:
	B() {	cout << "B()" << endl;	}
	~B() {	cout << "~B()" << endl;	}
	void display() const
	{	cout << "B::_b :" << _b << endl;	}
private:
	long _b;
};
 
class C
{
public:
	C() {	cout << "C()" << endl;	}
	~C() {	cout << "~C()" << endl;	}

	void show() const
	{	cout << "C::_c " << _c << endl;	}
private:
	long _c;
};


//多重继承时，记得要在每一个基类的前面加上
//访问权限，否则就是采用了私有继承
//
//多重继承时，基类被初始化的顺序只与其被继承时的顺序有关，
//而与其在派生类构造函数的出是表达式中的顺序无关
class D
: public B
, public A
, public C
{
public:
	D()
	: B()
	, A()
	, C()
	{	cout << "D()" << endl;}

	~D() {	cout << "~D()" << endl;}

};


void test0() 
{
	D d;
	d.print();
	d.display();
	d.show();
} 
 
int main(void)
{
	test0();
	return 0;
}
