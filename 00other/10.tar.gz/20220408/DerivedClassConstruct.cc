 ///
 /// @file    DerivedClassConstruct.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-08 16:11:03
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Base
{
public:
	Base(): _ibase(0) { cout << "Base()" << endl;	}

	Base(int x)
	: _ibase(x)
	{	cout << "Base()" << endl;	}

	void print() const
	{	cout << "Base::_ibase:" << _ibase << endl;	}	

private:
	int _ibase;
};

class Derived
: public Base //接口继承
{
public:
	//1. 派生类内部没有显式提供构造函数，
	//但编译器会自动为派生类提供一个默认构造函数
	//该构造函数执行时，会初始化基类部分，进而调用
	//基类的默认构造函数

	void display() const
	{
		cout << "Derived::_iderived " << _iderived << endl;
	}

private:
	int _iderived;
};
 
void test0() 
{
	Derived d1;
	d1.print();
	d1.display();
 
} 
 
int main(void)
{
	test0();
	return 0;
}
