 ///
 /// @file    DerivedClassConstruct.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-04-08 16:11:03
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Base
{
public:
	Base(): _ibase(0) { cout << "Base()" << endl;	}

	Base(int x)
	: _ibase(x)
	{	cout << "Base()" << endl;	}

	~Base() {	cout << "~Base()" << endl;	}

	void print() const
	{	cout << "Base::_ibase:" << _ibase << endl;	}	

private:
	int _ibase;
};

class Derived
: public Base //接口继承
{
public:
	//2. 派生类有显式定义构造函数，基类没有显式定义构造函数
	//当创建派生类对象时，执行基类初始化时，也会自动调用
	//基类的默认构造函数
	
	//3.  派生类有显式定义构造函数，基类也有显式定义构造函数
	//当创建派生类对象时，执行基类初始化时，必须要显式在派生类
	//构造函数的初始化列表中，显式调用基类的有参构造函数
	
#if 1
//我们最好在这里显式加上基类的初始化,即使是调用默认构造函数
	Derived()
	: Base() 
	, _iderived(1)
	{	cout << "Derived()" << endl;	}
#endif

//因为Base的构造函数是public的, 
//并不是因为派生类继承了基类的构造函数
	Derived(int x, int y)
	: Base(x)  
	, _iderived(y)
	{
		cout << "Derived(int,int)" << endl;
	}

//当派生类析构函数被调用之后，会自动执行基类部分的析构函数
	~Derived() {	cout << "~Derived()" << endl;}

	void display() const
	{
		print();
		cout << "Derived::_iderived " << _iderived << endl;
	}

private:
	int _iderived;
};

void test1()
{
	Derived d1(10, 100);
	d1.print();
	d1.display();

	//Base b1(1);//Base(int)
	//b1.print();
}
 
void test0() 
{
	Derived d1;
	d1.print();
	d1.display();
} 
 
int main(void)
{
	/* test0(); */
	test1();
	return 0;
}
