 ///
 /// @file    Point.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-03-29 16:02:00
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Point
{
public:

	Point(int ix, int iy, int & num)
	: _ix(ix) 
	, _iy(iy)
	, _ref(num) //引用的初始化
	{
		cout << "Point(int,int)" << endl;
		//_ix = ix;//不能在这里进行初始化
		//_iy = iy;
	}

	
	void print()
	{
		cout << "(" << _ix
			 << "," << _iy
			 << ")" << endl;
	}

	~Point() {	cout << "~Point()" << endl;}

private:
	int _ix = 10;
	int _iy = 10;
	int & _ref;
};
 
void test0() 
{	
#if 1
	int a = 1;//
	int b = a;//复制

	int c(1);
	cout << "c = " << c << endl;

	//Point pt0();//这是一个函数声明
	//pt0.print();

	Point pt(a, b, c);//没有传递参数，调用的无参构造函数
	cout << "pt:";
	pt.print();

	Point pt2 = pt;//完成了对象的复制
	cout << "pt2:";
	pt2.print();

	//    Point(const Point &);//拷贝构造函数
	//Point(Point x);
	Point pt3(pt);//效果相同
	cout << "pt3:";
	pt3.print();
#endif
}

 
int main(void)
{
	test0();
	return 0;
}
