 ///
 /// @file    Point.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-03-29 16:02:00
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Point
{
public:
	Point(int ix = 0, int iy = 0)
	: _ix(ix)
	, _iy(iy)
	{
		cout << "Point(int,int)" << endl;
	}

	Point(const Point & rhs)
	: _ix(rhs._ix)
	, _iy(rhs._iy)
	{
		cout << "Point(const Point &)" << endl;
	}
	
	//每一个成员函数都拥有一个隐含的this指针
	//this指针作为成员函数的第一个参数的
	//编译器在编译时会自动加上
	//this指针代表的是当前对象
	//void print(/* Point * this  */)
	void print(/* Point * const this  */)
	{
		//该this能否改变指向?
		//this = 0x1000;
		//this = &pt;
		cout << "(" << this->_ix
			 << "," << this->_iy
			 << ")" << endl;
	}

	~Point() {	cout << "~Point()" << endl;}

private:
	int _ix;
	int _iy;
};
 
void test0() 
{	
	Point pt1(1, 2);
	cout << "pt1:";
	pt1.print();//编译器会自动进行处理
	// ==> Point::print(&pt1);

	Point pt2(3, 4);
	cout << "pt2:";
	pt2.print();
}

 
int main(void)
{
	test0();
	return 0;
}
