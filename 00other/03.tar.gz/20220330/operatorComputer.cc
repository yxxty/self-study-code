 ///
 /// @file    Computer.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-03-29 14:50:39
 ///

#include <string.h>

#include <iostream>
using std::cout;
using std::endl;

class Computer
{
public:
	Computer(const char * brand, double price)
	: _brand(new char[strlen(brand) + 1]())
	, _price(price)
	{
		strcpy(_brand, brand);
		cout << "Computer(const char*, double)" << endl;
	}
	
	Computer(const Computer &rhs)
	: _brand(new char[strlen(rhs._brand) + 1]())//先开空间  
	, _price(rhs._price)
	{
		strcpy(_brand, rhs._brand);//再复制数据 => 深拷贝
		cout << "Computer(const Computer&)" << endl;
	}

	//系统提供的实现
#if 0
	Computer & operator=(const Computer & rhs)
	{
		this->_brand = rhs._brand;
		this->_price = rhs._price;
		return *this;
	}
#endif
	Computer & operator=(const Computer & rhs)
	{
		cout << "Computer& operator=(const Computer&)" << endl;
		if(this != &rhs) {//1. 自复制的判断
			if(_brand) {
				delete [] this->_brand;//2. 回收左操作数的空间
			}

			_brand = new char[strlen(rhs._brand) + 1]();
			strcpy(_brand, rhs._brand);//3. 进行深拷贝

			_price = rhs._price;
		}
		return *this;//4. 返回对象本身
	}


	void print()
	{
		printf("_brand: %p\n", _brand);
		cout << "品牌:" <<  _brand << endl
			 << "价格:" << _price << endl;
	}

	~Computer()
	{
		release();
	}

	void release()
	{
		if(_brand) {
			delete [] _brand;
			_brand = nullptr;//NULL
		}
		cout << "~Computer()" << endl;
	}

private:
	char * _brand;//由于_brand申请了堆空间的资源
	double _price;//必须要进行回收,系统提供
};

 
void test0() 
{
	Computer c1("小米", 7777);//创建对象
	cout << "sizeof(Computer):" << sizeof(Computer) << endl;
	cout << "sizeof(c1): " << sizeof(c1) << endl;

	cout << "c1:";
	c1.print();

	Computer c2(c1);//调用Computer的拷贝构造函数
	cout << "c2:";
	c2.print();
} 

void test1()
{
	Computer c1("小米", 7777);//创建对象
	Computer c2("华为 matebook", 8888);

	c1 = c2;//调用赋值运算符函数
	cout << "c1:";
	c1.print();

	cout << endl << "c2:" << endl;
	c2.print();

	int a = 1;
	a = a;
	c1 = c1;//自复制, 什么事儿都不做

}
 
int main(void)
{
	/* test0(); */
	test1();
	return 0;
}
