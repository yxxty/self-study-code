 ///
 /// @file    Point.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-03-29 16:02:00
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Point
{
public:
	Point(int ix = 0, int iy = 0)
	: _ix(ix)
	, _iy(iy)
	{
		cout << "Point(int,int)" << endl;
	}

	Point(const Point & rhs)
	: _ix(rhs._ix)
	, _iy(rhs._iy)
	{
		cout << "Point(const Point &)" << endl;
	}

	//系统会自动提供一个
	Point & operator=(const Point & rhs)
	{
		_ix = rhs._ix;
		_iy = rhs._iy;
		cout << "Point & operator=(const Point&)" << endl;

		return (*this);
	}

	
	void print()
	{
		cout << "(" << _ix
			 << "," << _iy
			 << ")" << endl;
	}

	~Point() {	cout << "~Point()" << endl;}

private:
	int _ix;
	int _iy;
};
 
void test0() 
{	
#if 1
	int a = 1;//
	int b = a;//复制

	//Point pt0();//这是一个函数声明
	//pt0.print();

	Point pt;//没有传递参数，调用的无参构造函数
	cout << "pt:";
	pt.print();

	//该语句之前pt2没有创建完毕
	Point pt2 = pt;//完成了对象的复制
	cout << "pt2:";
	pt2.print();

	//    Point(const Point &);//拷贝构造函数
	//Point(Point x);
	Point pt3(pt);//效果相同
	cout << "pt3:";
	pt3.print();
#endif
}

void test1()
{
	int a = 1, b = 2;
	a = b;//赋值语句

	Point pt(1, 2), pt2(3, 4);
	//pt2已经创建完毕
	pt2 = pt;//赋值语句, 会调用赋值运算符函数
			 //重载运算符的功能
	pt2.operator=(pt);

	cout << "pt:";
	pt.print();
	cout << "pt2:";
	pt2.print();
}

 
int main(void)
{
	/* test0(); */
	test1();
	return 0;
}
