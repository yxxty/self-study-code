 ///
 /// @file    Point.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-03-29 16:02:00
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Point
{
public:
	Point(int ix = 0, int iy = 0)
	: _ix(ix)
	, _iy(iy)
	{
		cout << "Point(int,int)" << endl;
	}

	Point(const Point & rhs)
	: _ix(rhs._ix)
	, _iy(rhs._iy)
	{
		cout << "Point(const Point &)" << endl;
	}
	
	void print()
	{
		cout << "(" << _ix
			 << "," << _iy
			 << ")" << endl;
	}

	~Point() {	cout << "~Point()" << endl;}

private:
	int _ix;
	int _iy;
};
 
void test0() 
{	
#if 0
	int a = 1;//
	int b = a;//复制

	//Point pt0();//这是一个函数声明
	//pt0.print();

	Point pt;//没有传递参数，调用的无参构造函数
	cout << "pt:";
	pt.print();

	Point pt2 = pt;//完成了对象的复制
	cout << "pt2:";
	pt2.print();

	//    Point(const Point &);//拷贝构造函数
	//Point(Point x);
	Point pt3(pt);//效果相同
	cout << "pt3:";
	pt3.print();
#endif
	

	//该对象是没有名字的,称为匿名对象
	//匿名对象的生命周期只在这一句中
	//匿名对象又称为临时对象
	//不能做取地址操作, 又称为右值
	//能够取地址的称为左值
	Point(1, 2).print();
	cout << "11111111111" << endl;

	//用匿名对象初始化一个新对象
	Point pt4 = Point(1, 2);
	cout << "pt4:" << endl;
	pt4.print();

	&Point(1, 2);
	&1;
	//非const左值引用不能绑定到临时对象
	int & num = 1;//字面值常量

	const int & number = 1;

}

 
int main(void)
{
	test0();
	return 0;
}
