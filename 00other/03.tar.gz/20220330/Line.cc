 ///
 /// @file    Point.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-03-29 16:02:00
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Point
{
public:

	Point(int ix = 0, int iy = 0)
	: _ix(ix) 
	, _iy(iy)
	{
		cout << "Point(int,int)" << endl;
	}

	
	void print()
	{
		cout << "(" << _ix
			 << "," << _iy
			 << ")";
	}

	~Point() {	cout << "~Point()" << endl;}

private:
	int _ix = 10;
	int _iy = 10;
};


class Line
{
public:
	//默认情况下，类对象成员的初始化会调用
	//相应的默认（无参）构造函数
	Line(int x1, int y1, int x2, int y2)
	: _pt1(x1, y1)
	, _pt2(x2, y2)
	{
		cout << "Line(int,int,int,int)" << endl;
	}

	void printLine()
	{
		_pt1.print();
		cout << " --> ";
		_pt2.print();
		cout << endl;
	}

private:
	//类对象成员
	Point _pt1;
	Point _pt2;
};

 
void test0() 
{	
	Line line(1, 2, 3, 4);
	line.printLine();
}

 
int main(void)
{
	test0();
	return 0;
}
