 ///
 /// @file    Point.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-03-29 16:02:00
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Point
{
public:
	//告诉编译器要生成一个默认(无参)构造函数
	Point() = default;

	Point(int ix, int iy)
	: _ix(ix) 
	, _iy(iy)
	{
		cout << "Point(int,int)" << endl;
		//_ix = ix;//不能在这里进行初始化
		//_iy = iy;
	}

	Point(const Point & rhs)
	: _ix(rhs._ix)
	, _iy(rhs._iy)
	{
		cout << "Point(const Point &)" << endl;
	}
	
#if 0
	void print(/* Point * const this  */)
	{
		cout << "void print()" << endl;
		cout << "(" << _ix
			 << "," << _iy
			 << ")" << endl;
	}
#endif

#if 1
	//const修饰成员函数时，本质上就是
	//改变了this指针的形态,编译器会自动进行该操作
	void print(/* const Point* const this */) const
	{
		cout << "void print() const" << endl;
		//_ix = 10;//error
		cout << "(" << _ix
			 << "," << _iy
			 << ")" << endl;
	}
#endif

	~Point() {	cout << "~Point()" << endl;}

private:
	int _ix = 10;
	int _iy = 10;
};
 
void test0() 
{	
	//非const对象调用非const的成员函数
	//非const对象也可以调用const成员函数
	Point pt(1, 2);
	pt.print();

	//const对象调用const的成员函数
	const Point pt2(3, 4);
	pt2.print();

}

 
int main(void)
{
	test0();
	return 0;
}
