 ///
 /// @file    Point.cc
 /// @author  lemon(haohb13@gmail.com)
 /// @date    2022-03-29 16:02:00
 ///
 
#include <iostream>
using std::cout;
using std::endl;

class Point
{
public:
	Point(int ix = 0, int iy = 0)
	: _ix(ix)
	, _iy(iy)
	{
		cout << "Point(int,int)" << endl;
	}

	//系统会自动提供一个拷贝构造函数
	Point(const Point & rhs)
	: _ix(rhs._ix)
	, _iy(rhs._iy)
	{
		cout << "Point(const Point &)" << endl;
	}
	
	void print()
	{
		cout << "(" << _ix
			 << "," << _iy
			 << ")" << endl;
	}

private:
	int _ix;
	int _iy;
};
 
void test0() 
{	
	int a = 1;//
	int b = a;//复制

	//Point pt0();//这是一个函数声明
	//pt0.print();

	Point pt;//没有传递参数，调用的无参构造函数
	cout << "pt:";
	pt.print();

	Point pt2 = pt;//完成了对象的复制
	cout << "pt2:";
	pt2.print();

	//    Point(const Point &);//拷贝构造函数
	//Point(Point x);
	Point pt3(pt);//效果相同
	cout << "pt3:";
	pt3.print();
}

//2. 当形参也是对象，形参与实参进行结合时,
//会调用拷贝构造函数
void func(Point x) // Point x = pt;
{
	cout << "func(): x "<< endl;
	x.print();
}

//3. 当函数的返回值是对象，执行return语句时
//调用拷贝构造函数
Point getPoint()
{
	Point pt(3, 4);
	cout << "getPoint(): pt" << endl;
	pt.print();
	return pt;
}

void test1()
{
	Point pt(1, 2);
	func(pt);
}

void test2()
{
	Point x = getPoint();
	cout << "x:" << endl;
	x.print();
}

 
int main(void)
{
	/* test0(); */
	/* test1(); */
	test2();
	return 0;
}
