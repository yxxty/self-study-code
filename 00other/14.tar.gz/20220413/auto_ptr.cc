#include <iostream>
#include <memory>

using std::cout;
using std::endl;
using std::auto_ptr;

void test()
{
    //裸指针
    int *pInt = new int(10);
    auto_ptr<int> ap(pInt);//ap智能指针
    cout << "*ap = " << *ap << endl;
    cout << "pInt = " << pInt << endl;
    cout << "ap.get() = " << ap.get() << endl;

    cout << endl;
    auto_ptr<int> ap2(ap);//表面上执行的是拷贝操作，但是底层已经发生了
                          //所有权的转移,该智能指针存在缺陷
    cout << "*ap2 = " << *ap2 << endl;
    cout << "*ap = " << *ap << endl;
    
}

int main(int argc, char **argv)
{
    test();
    return 0;
}

