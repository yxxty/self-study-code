#include <string.h>
#include <iostream>

using std::cout;
using std::endl;

class String
{
public:
    String()
    : _pstr(nullptr)
    {
        cout << "String()" << endl;
    }

    String(const char *pstr)
    : _pstr(new char[strlen(pstr) + 1]())
    {
        cout << "String(const char *)" << endl;
        strcpy(_pstr, pstr);
    }

    //String s3 = String("world");
    String(const String &rhs)
    : _pstr(new char[strlen(rhs._pstr) + 1]()) 
    {
        cout << "String(const String &)" << endl;
        strcpy(_pstr, rhs._pstr);
    }

    //移动构造函数,必须手动写出，编译器不会主动生成
    String(String &&rhs)
    : _pstr(rhs._pstr)
    {
        cout << "String(String &&)" << endl;
        rhs._pstr = nullptr;
    }

    //s1 = s2
    String &operator=(const String &rhs)
    {
        cout << "String &operator=(const String &)" << endl;
        if(this != &rhs)
        {
            delete [] _pstr;
            _pstr = nullptr;

            _pstr = new char[strlen(rhs._pstr) + 1]();
            strcpy(_pstr, rhs._pstr);
        }

        return *this;
    }

    //移动赋值运算符函数
    //s3 = String("wangdao")
    String &operator=(String &&rhs)
    {
        cout << "String &operator=(String &&)" << endl;
        if(this != &rhs)//1、自移动
        {
            delete [] _pstr;
            _pstr = nullptr;

            _pstr = rhs._pstr;
            rhs._pstr = nullptr;
        }

        return *this;
    }

    ~String()
    {
        cout << "~String()" << endl;
        if(_pstr)
        {
            delete [] _pstr;
            _pstr = nullptr;
        }
    }

    friend std::ostream &operator<<(std::ostream &os, const String &rhs);
private:
    char *_pstr;
};
std::ostream &operator<<(std::ostream &os, const String &rhs)
{
    if(rhs._pstr)
    {
        os << rhs._pstr;
    }
    return os;
}

void test()
{
    String s1("hello");
    cout << "s1 = " << s1 << endl;

    cout << endl;
    String s2 = s1;
    cout << "s1 = " << s1 << endl;
    cout << "s2 = " <<s2 <<endl;

    cout << endl;
    //C++        C
    /* String s3 = "world";//String("world") */
    String s3 = String("world");//String("world")
    cout << "s3 = " << s3 << endl;
    &"world";

    cout << endl;
    s3 = String("wangdao");
    cout << "s3 = " << s3 << endl;

    cout << endl;
    String("hello") = String("hello");

    cout << endl;
    //可以将左值转换为为右值,表明以后不想再使用该值
    //static_cast<T &&>(lvalue)
    s3 = std::move(s3);
    cout << "s3 = " << s3 << endl;


}
int main(int argc, char **argv)
{
    test();
    return 0;
}

