#include <iostream>

using std::cout;
using std::endl;

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        cout << "Point(int = 0, int = 0)" << endl;
    }

    void print()
    {
        cout << "(" << _ix
             << ", " << _iy
             << ")" << endl;
    }

    ~Point()
    {
        cout << "~Point()" << endl;
    }

private:
    int _ix;
    int _iy;
};

template <typename T>
class RAII
{
public:
    //构造函数中获取资源（初始化资源）
    RAII(T *data)
    : _data(data)
    {
        cout << "RAII(T *)" << endl;
    }

    //提供若干访问资源的方法
    T *operator->()
    {
        return _data;
    }

    T &operator*()
    {
        return *_data;
    }

    T *get()
    {
        return _data;
    }

    void reset(T *data)
    {
        if(_data)
        {
            delete _data;
            _data = nullptr;
        }
        _data = data;
    }

    //析构函数中释放资源
    ~RAII()
    {
        cout << "~RAII()" << endl;
        if(_data)
        {
            delete _data;
            _data = nullptr;
        }
    }

    //不允许复制或者赋值
private:
    RAII(const RAII &rhs);
    RAII &operator=(const RAII &rhs);
private:
    T *_data;
};

int main(int argc, char **argv)
{
    RAII<Point> pt(new Point(1, 2));//pt栈对象
    pt->print();
    /* pt.operator->()->print(); */

    /* RAII<Point> pt2 = pt;//error */

    return 0;
}

