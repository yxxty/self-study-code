#include <iostream>

using std::cout;
using std::endl;

template <typename T1, typename T2, typename T3>
void dis(T1 t1, T2 t2, T3 t3)
{

}


template <typename ... Args>//Args模板参数包
void display(Args ... args)//args函数参数包,...位于参数左边的时候称为打包
{
    cout << "sizeof...(Args) = " << sizeof...(Args) << endl;
    cout << "sizeof...(args) = " << sizeof...(args) << endl;

    /* cout << "args..." << args... << endl;//error */
}

void test()
{
    display();
    display(1);//int
    display(1, true, "hello");//int bool string
}

void print()
{
    cout <<endl;
}
template <typename T, typename  ... Args>
void print(T t, Args ...args)
{
    cout << t << "  ";
    print(args...);//...位于参数右边的时候称为解包
}

void test2()
{
    print();
    print(1, true, "hello", 3.4);
    //cout << 1 << " ";
    //print(true, "hello", 3.4)
    //   cout << 1 << "  ";
    //   print("hello", 3.4);
    //      cout << "hello" << "  ";
    //      print(3.4);
    //          cout << 3.4 << " ";
    //          print();
    //             cout << endl;
}

int sum()
{
    return 0;
}

template <typename T, typename  ... Args>
int sum(T t, Args ...args)
{
    return t + sum(args...);
}

void test3()
{
    cout << "sum(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) = " 
         << sum(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) << endl;
}
int main(int argc, char **argv)
{
    test3();
    return 0;
}

