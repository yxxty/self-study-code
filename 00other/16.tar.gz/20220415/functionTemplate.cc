#include <string.h>
#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;

/* template <class T> */
template <typename T>
T add(T t1, T t2)
{
    cout << "T add(T, T)" << endl;
    return t1 + t2;
}

template <typename T>
T add(T t1, T t2, T t3)
{
    cout << "T add(T, T)" << endl;
    return t1 + t2 + t3;
}

#if 1
int add(int t1, int t2)
{
    cout <<"int add(int, int)" << endl;
    return t1 + t2;
}
#endif

//从函数模板推导到具体函数（实例化）
//隐式实例化  显示实例化


//模板的特化
//模板的全特化和偏特化（部分特化）
template <>
const char *add(const char *ps1, const char *ps2)
{
    cout << "const char *add(const char *, const char *)" << endl;
    size_t len = strlen(ps1) + strlen(ps2) + 1;
    char *pstr = new char[len]();
    strcpy(pstr, ps1);
    strcat(pstr, ps2);

    return pstr;
}
void test()
{
    int ia = 3, ib = 4;
    double da = 3.3, db = 4.4;
    char ca = 'a', cb = 1;

    string s1 = "hello";
    string s2 = "world";

    const char *pstr1 = "hello";
    const char *pstr2 = "world";

    cout << "add(ia, ib) = " << add<int>(ia, ib) << endl;//显示实例化
    cout << "add(da, db) = " << add(da, db) << endl;//隐式实例化
    cout << "add(ca, cb) = " << add(ca, cb) << endl;
    cout << "add(s1, s2) = " << add(s1, s2) << endl;

    cout << "add(ia, db) = " << add(ia, db) << endl;//隐式实例化

    cout << "add(pstr1, pstr2) = " << add(pstr1, pstr2) << endl;
}

int main(int argc, char **argv)
{
    test();
    return 0;
}

