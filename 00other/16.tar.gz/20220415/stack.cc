#include <iostream>

using std::cout;
using std::endl;

//类模板
template <typename  T, int size = 10>
class Stack
{
public:
    Stack()
    : _top(-1)
    , _size(size)
    , _data(new T[_size]())
    {
        cout << "Stack(int = 0)" << endl;
    }

    bool empty() const;
    bool full() const;
    void push(const T &value);
    void pop();
    T top() const;
    ~Stack();
private:
    int _top;
    int _size;
    T *_data;
};

template <typename T, int size>
bool Stack<T, size>::empty() const
{
    return _top == -1;
}

template <typename T, int size>
bool Stack<T, size>::full() const
{
    return _top == _size - 1;
}

template <typename T, int size>
void Stack<T, size>::push(const T &value)
{
    if(!full())
    {
        _data[++_top] = value;
    }
    else
    {
        cout << "can not push any data" << endl;
        return;
    }
}

template <typename T, int size>
void Stack<T, size>::pop()
{
    if(!empty())
    {
        --_top;
    }
    else
    {
        cout << "can not pop any data" << endl;
        return;
    }
}

template <typename T, int size>
T Stack<T, size>::top() const
{
    return _data[_top];
}

template <typename T, int size>
Stack<T, size>::~Stack()
{
    cout << "~Stack()" << endl;
    if(_data)
    {
        delete [] _data;
        _data = nullptr;
    }
}

void test()
{
    Stack<int> st;
    cout << "栈是不是空的？" << st.empty() << endl;
    st.push(1);
    cout << "栈是不是满的？" << st.full() << endl;

    for(int idx = 2; idx != 12;++idx)
    {
        st.push(idx);
    }
    cout << "栈是不是满的？" << st.full() << endl;

    while(!st.empty())
    {
        cout << st.top() << "  ";
        st.pop();
    }
    cout << endl;
    cout << "栈是不是空的？" << st.empty() << endl;
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

