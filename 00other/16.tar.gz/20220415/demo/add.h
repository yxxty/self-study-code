#ifndef __ADD_H__
#define __ADD_H__

//模板是不能分成头文件与实现文件的，否则就会报错（编译不过）
//或者说不能将声明与实现分开，如果一定要分开，可以在头文件
//中#include实现文件
template <typename T>
T add(T t1, T t2);

#include "add.cc"

#endif
