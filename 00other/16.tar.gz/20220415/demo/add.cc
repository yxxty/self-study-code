/* #include "add.h" */
template <typename T>
T add(T t1, T t2)
{
    return t1 + t2;
}
