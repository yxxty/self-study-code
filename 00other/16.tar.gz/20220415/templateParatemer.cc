#include <iostream>

using std::cout;
using std::endl;

//模板的参数类型：
//1、类型参数  T
//2、非类型参数，整型:bool/short/int/long/void *(float/double除外)
template <typename T = int, short kMin = 10>
T multiply(T t1, T t2)
{
    return t1 * t2 * kMin;
}

int main(int argc, char **argv)
{
    int ia = 3, ib = 4;
    double da = 3.3, db = 4.4;

    cout << "multiply(ia, ib) = " << multiply<int>(ia, ib) << endl;
    cout << "multiply(da, db) = " << multiply<double, 200>(da, db) << endl;
    return 0;
}

