#include <iostream>

using std::cout;
using std::endl;

#if 0
void test();
void test();
void test();
void test();
void test()
{

}
void test()
{

}
#endif

//声明了纯虚函数的类称为抽象类，抽象类是不能创建对象的
class Base
{
public:
    virtual void print() const = 0;//纯虚函数
    virtual void show() const = 0;//纯虚函数
};

//抽象类的派生类如果有至少一个纯虚函数没有实现，那么抽象类
//的派生类也是抽象类；抽象类是不能创建对象的
class Derived
: public Base
{
public:
    virtual void print() const override
    {
        cout << "Derived::print() const " << endl;
    }

};

class Derived2
: public Derived
{
public:
    virtual void show() const override
    {
        cout << "Derived2::show() const " << endl;
    }
};

int main(int argc, char **argv)
{
    /* Base base;//error */
    /* Derived derived; */
    /* derived.print(); */

    Derived2 d2;
    d2.print();
    d2.show();

    cout << endl;
    Base *pbase = &d2;;
    Derived *pderived = &d2;
    return 0;
}

