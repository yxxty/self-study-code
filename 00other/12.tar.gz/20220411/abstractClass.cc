#include <iostream>

using std::cout;
using std::endl;

//将构造函数用protected进行修饰，那么该类也是抽象类
class Base
{
public:
private:
protected:
    Base()
    {
        cout << "Base()" << endl;
    }
};

class Derived
: public Base
{
public:
    Derived()
    {
        cout << "Derived()" << endl;
    }
};
int main(int argc, char **argv)
{
    /* Base base;//error */
    return 0;
}

