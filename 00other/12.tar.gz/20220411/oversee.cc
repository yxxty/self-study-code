#include <iostream>

using std::cout;
using std::endl;

class Base
{
public:
    Base(long number = 0)
    : _number(number)
    {
        cout << "Base(long = 0)" << endl;
    }

    virtual
    void print() const
    {
        cout << "Base::_number = " << _number << endl;
    }
/* private: */
protected:
    long _number;
};

class Derived
: public Base
{
public:
    Derived(long number = 0, long number2 = 0)
    : Base(number)
    , _number(number2)
    {
        cout << "Derived(long = 0, long  = 0)" << endl;
    }

    virtual
    /* void print() const */
    void print(int x) const
    {
        cout << "x = " << x << endl;
        cout << "Base::_number = " << Base::_number << endl;
        cout << "_number = " << this->_number << endl;
    }
private:
    long _number;
};
int main(int argc, char **argv)
{
    Base base(10);
    base.print();

    cout << endl;
    Derived derived(20, 30);
    derived.print(100);
    derived.Base::print();//oversee
    return 0;
}

