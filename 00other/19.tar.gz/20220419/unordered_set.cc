#include <math.h>
#include <iostream>
#include <unordered_set>

using std::cout;
using std::endl;
using std::unordered_set;

template <typename container>
void display(const container &con)
{
    for(auto &elem : con)
    {
        cout << elem << "  ";
    }

    cout << endl;
}

void test()
{
    unordered_set<int> number = {1, 6, 8, 3, 3, 3, 4, 9, 2, 7};
    display(number);
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    void print() const
    {
        cout << "(" << _ix
             << ", " << _iy
             << ")" << endl;
    }
    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    int getX() const
    {
        return _ix;
    }

    int getY() const
    {
        return _iy;
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);

private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "(" << rhs._ix
       << "," << rhs._iy 
       << ")";

    return os;
}

namespace std
{
//模板的特化
template <>
struct hash<Point>
{
    size_t operator()(const Point &rhs) const
    {
        return (rhs.getX() << 1) ^(rhs.getY() << 2);
    }
};//end of struct hash

}//end of namespace std

struct HashPoint
{
    size_t operator()(const Point &rhs) const
    {
        cout << "size_t operator()(const Point &) const" << endl;
        return (rhs.getX() << 1) ^(rhs.getY() << 2);
    }

};


bool operator==(const Point &lhs, const Point &rhs)
{
    return ((lhs.getX() == rhs.getX())&& (lhs.getY() == rhs.getY()));
}
void test2()
{
    unordered_set<Point, HashPoint> number = {
        Point(1, 2),
        Point(1, 2),
        Point(-1, 3),
        Point(10, 3),
        Point(4, 4),
    };
    display(number);
}

int main(int argc, char **argv)
{
    test2();
    return 0;
}

