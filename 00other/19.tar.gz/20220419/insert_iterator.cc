#include <iostream>
#include <vector>
#include <list>
#include <set>
#include <iterator>
#include <algorithm>

using std::cout;
using std::endl;
using std::vector;
using std::list;
using std::set;
using std::ostream_iterator;
using std::copy;

void test()
{
    vector<int> vecNumber = {1, 3, 7, 9};
    list<int> listNumber = {10, 30, 40, 70};
    copy(listNumber.begin(), listNumber.end(), std::back_inserter(vecNumber));
    copy(vecNumber.begin(), vecNumber.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;

    copy(vecNumber.begin(), vecNumber.end(), std::front_inserter(listNumber));
    copy(listNumber.begin(), listNumber.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;

    set<int> setNumber = {4, 6, 10, 5, 3, 1};
    auto it = setNumber.begin();
    copy(vecNumber.begin(), vecNumber.end(), std::inserter(setNumber, it));
    copy(setNumber.begin(), setNumber.end(), ostream_iterator<int>(cout, "  "));
    cout << endl;
}
int main(int argc, char **argv)
{
    test();
    return 0;
}

