#include <math.h>
#include <iostream>
#include <queue>
#include <vector>

using std::cout;
using std::endl;
using std::priority_queue;
using std::vector;


void test()
{
    //优先级队列底层使用的是堆排序，默认情况下是一个大顶堆（大根堆）
    //当有元素插入进来的时候会与堆顶进行比较，当堆顶比插入的元素
    //要小的时候（满足std::less）的时候，就会将新插入的元素与堆顶
    //进行置换，新的元素成为新的堆顶，如果堆顶比新插入的元素要大
    //的时候，不满足std::less,所以新的堆顶依旧还是老的堆顶上的元素
    priority_queue<int> pque;
    vector<int> number = {1, 5, 9, 4, 6, 2, 8};
    for(size_t idx = 0; idx != number.size(); ++idx)
    {
        pque.push(number[idx]);
        cout << "优先级最高的元素是: "<< pque.top() << endl;
    }

    while(!pque.empty())
    {
        cout << pque.top() << "  ";
        pque.pop();
    }
    cout << endl;
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        /* cout << "Point(int = 0, int = 0)" << endl; */
    }

    void print() const
    {
        cout << "(" << _ix
             << ", " << _iy
             << ")" << endl;
    }
    double getDistance() const
    {
        return hypot(_ix, _iy);
    }

    ~Point()
    {
        /* cout << "~Point()" << endl; */
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);
    friend bool operator<(const Point &lhs, const Point &rhs);
    friend bool operator>(const Point &lhs, const Point &rhs);
    friend struct Compare;

private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "(" << rhs._ix
       << "," << rhs._iy 
       << ")";

    return os;
}

bool operator<(const Point &lhs, const Point &rhs)
{
    /* cout << "bool operator<(const Point &, const Point &)" << endl; */
    if(lhs.getDistance() < rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs._ix < rhs._ix)
        {
            return true;
        }
        else if(lhs._ix == rhs._ix)
        {
            if(lhs._iy < rhs._iy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

bool operator>(const Point &lhs, const Point &rhs)
{
    /* cout << "bool operator>(const Point &, const Point &)" << endl; */
    if(lhs.getDistance() > rhs.getDistance())
    {
        return true;
    }
    else if(lhs.getDistance() == rhs.getDistance())
    {
        if(lhs._ix > rhs._ix)
        {
            return true;
        }
        else if(lhs._ix == rhs._ix)
        {
            if(lhs._iy > rhs._iy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

struct Compare
{
    bool operator()(const Point &lhs, const Point &rhs) const
    {
        /* cout << "bool operator()(const T &, const T &)" << endl; */
        if(lhs.getDistance() > rhs.getDistance())
        {
            return true;
        }
        else if(lhs.getDistance() == rhs.getDistance())
        {
            if(lhs._ix > rhs._ix)
            {
                return true;
            }
            else if(lhs._ix == rhs._ix)
            {
                if(lhs._iy > rhs._iy)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
};

void test2()
{
    /* priority_queue<Point> pque; */
    /* priority_queue<Point, vector<Point>, std::greater<Point>> pque; */
    priority_queue<Point, vector<Point>, Compare> pque;
    vector<Point> number = {
        Point(1, 2),
        Point(3, 4),
        Point(10, 2),
        Point(-1, 2),
        Point(-1, 0),
    };
    for(size_t idx = 0; idx != number.size(); ++idx)
    {
        pque.push(number[idx]);
        cout << "优先级最高的元素是: "<< pque.top() << endl;
    }

    while(!pque.empty())
    {
        cout << pque.top() << "  ";
        pque.pop();
    }
    cout << endl;
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

