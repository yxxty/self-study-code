#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>

using std::cout;
using std::endl;
using std::ostream_iterator;
using std::vector;
using std::copy;

//cout << 1 << 3 << 5 << 7 << 9 << 8 << "\n"
int main(int argc, char **argv)
{
    vector<int> number = {1, 3, 5, 7, 9, 8};
    ostream_iterator<int> osi(cout, "\n");
    copy(number.begin(), number.end(), osi);

    return 0;
}

