#include <iostream>
#include <vector>
#include <iterator>

using std::cout;
using std::endl;
using std::vector;
using std::reverse_iterator;

int main(int argc, char **argv)
{
    vector<int> number = {1, 5, 9, 7, 5 ,3, 2, 6};
    vector<int>::reverse_iterator rit;
    for(rit = number.rbegin(); rit != number.rend(); ++rit)
    {
        cout << *rit << "  ";
    }
    cout << endl;
    return 0;
}

