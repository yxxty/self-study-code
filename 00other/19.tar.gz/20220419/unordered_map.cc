#include <iostream>
#include <unordered_map>
#include <string>

using std::cout;
using std::endl;
using std::unordered_map;
using std::string;

template <typename container>
void display(const container &con)
{
    for(auto &elem : con)
    {
        cout << elem.first << "  "
             << elem.second << endl;
    }

    cout << endl;
}

void test()
{
    unordered_map<int, string> number = {
        {1, "hello"},
        {2, "world"},
        std::pair<int, string>(4, "wangdao"),
        std::pair<int, string>(10, "wd"),
        std::make_pair(5, "wuhan"),
        std::make_pair(1, "wuhan"),
        std::make_pair(6, "wuhan"),
    };

    display(number);

    cout << endl << "unordered_map的下标访问" << endl;
    cout << "number[1] = " << number[1] << endl;
    cout << "number[7] = " << number[7] << endl;
    display(number);

    number[7] = "hubei";
    number.operator[](7).operator=("hubei");
    display(number);
}

class Point
{
public:
    Point(int ix = 0, int iy = 0)
    : _ix(ix)
    , _iy(iy)
    {
        cout << "Point(int = 0, int = 0)" << endl;
    }

    void print() const
    {
        cout << "(" << _ix
             << ", " << _iy
             << ")" << endl;
    }
    /* double getDistance() const */
    /* { */
    /*     return hypot(_ix, _iy); */
    /* } */

    ~Point()
    {
    }

    friend std::ostream &operator<<(std::ostream &os, const Point &rhs);

private:
    int _ix;
    int _iy;
};

std::ostream &operator<<(std::ostream &os, const Point &rhs)
{
    os << "(" << rhs._ix
       << "," << rhs._iy 
       << ")";

    return os;
}
void test2()
{
    unordered_map<string, Point> number = {
        {"1", Point(1, 2)},
        {"3", Point(3, 2)},
        std::pair<string, Point>("5", Point(4, 6)),
        std::pair<string, Point>("7", Point(4, 6)),
        std::make_pair("12", Point(1, 2)),
        std::make_pair("3", Point(1, 2)),
        std::make_pair("4", Point(1, 2)),
    };
    display(number);

    cout << endl << "unordered_map的下标访问" << endl;
    cout << "number[\"1\"]= " << number["1"] << endl;
    cout << "number[\"8\"] = " << number["8"] << endl;
    display(number);
    number["8"] = Point(10, 20);

    cout << endl << "unordered_map的查找" << endl;
    size_t cnt1 = number.count("1");
    size_t cnt2 = number.count("13");
    cout << "cnt1 = " << cnt1 << endl;
    cout << "cnt2 = " << cnt2 << endl;

    cout << endl << "unordered_map的insert操作" << endl;
    /* std::pair<map<string, Point>::iterator, bool> ret = */ 
    /*     number.insert({"1", Point(1, 2)}); */
    /* std::pair<map<string, Point>::iterator, bool> ret = */ 
    /*     number.insert(std::pair<string, Point>("1", Point(1, 2))); */
    /* std::pair<map<string, Point>::iterator, bool> ret = */ 
    /*     number.insert(std::make_pair("1", Point(1, 2))); */
    auto ret = number.insert(std::make_pair("1", Point(1, 2)));
    if(ret.second)
    {
        cout << "插入成功" << ret.first->first 
            << "  " << ret.first->second << endl;
    }
    else
    {
        cout << "插入失败,该元素存在unordered_map中" << endl;
    }
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

