#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>

using std::cout;
using std::endl;
using std::ostream_iterator;
using std::istream_iterator;
using std::vector;
using std::copy;

int main(int argc, char **argv)
{
    vector<int> number;
    cout <<"111" << endl;
    istream_iterator<int> isi(std::cin);
    cout <<"222" << endl;
    //对于vector而言，插入元素要使用push_back
    /* copy(isi, istream_iterator<int>(), number.begin()); */
    copy(isi, istream_iterator<int>(), std::back_inserter(number));
    cout <<"333" << endl;

    copy(number.begin(), number.end(), ostream_iterator<int>(cout, "\n"));
    cout <<"444" << endl;
    return 0;
}

