#include <iostream>

using std::cout;
using std::endl;

//拥有某种类型的指针与拥有某种类型的对象数据成员是不一样
class Order;

class Customer
{
private:
    Order *_order;
};


class Order
{
private:
    Customer _cus;
};

int main(int argc, char **argv)
{
    cout << "sizeof(Customer) = " << sizeof(Customer) << endl;
    cout << "sizeof(Order) = " << sizeof(Order) << endl;
    return 0;
}

