#include <iostream>
#include <string>
#include <vector>

using std::cout;
using std::endl;
using std::string;
using std::vector;


class Building
{
public:
    virtual void sale() = 0;
    virtual string getQuality() = 0;
    virtual ~Building(){}
};

class WankeBuilding
: public Building
{
public:
    WankeBuilding()
    : _quality("高品质")
    {

    }

    void sale()
    {
        cout << "万科楼盘 " << _quality << "房子被出售" << endl;
    }

    string getQuality() 
    {
        return _quality;
    }
    
private:
    string _quality;
};

class LanguangBuilding
: public Building
{
public:
    LanguangBuilding()
    : _quality("低品质")
    {

    }

    void sale()
    {
        cout << "蓝光楼盘 " << _quality << "房子被出售" << endl;
    }

    string getQuality() 
    {
        return _quality;
    }
    
private:
    string _quality;
};

class Mediator
{
public:
    Mediator()
    {
        Building *buildingA = new WankeBuilding();
        Building *buildingB = new LanguangBuilding();
        _building.push_back(buildingA);
        _building.push_back(buildingB);
    }

    Building *findBuilding(const string &quality)
    {
        for(auto &building : _building)
        {
            if(building->getQuality() == quality)
            {
                return building;
            }
        }

        return nullptr;
    }

    ~Mediator()
    {
        for(auto &building : _building)
        {
            if(building)
            {
                delete building;
                building = nullptr;
            }
        }
    }

private:
    vector<Building *> _building;
};

void test1()
{
    Building *pbuildingA = new WankeBuilding();
    Building *pbuildingB = new LanguangBuilding();

    string demand = "低品质";
    if(pbuildingA->getQuality() == demand)
    {
        pbuildingA->sale();
    }

    if(pbuildingB->getQuality() == demand)
    {
        pbuildingB->sale();
    }
}

void test2()
{
    string demand = "高品质";
    Mediator mediator;
    Building *myBuilding = mediator.findBuilding(demand);
    if(myBuilding)
    {
        myBuilding->sale();
    }
    else
    {
        cout << "没有符合需求的楼盘" << endl;
    }
}
int main(int argc, char **argv)
{
    test2();
    return 0;
}

