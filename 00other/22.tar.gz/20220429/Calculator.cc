#include <iostream>

using std::cout;
using std::endl;

class Calculator
{
public:
    int plus(int x, int y)
    {
        return x + y;
    }

    int minus(int x, int y)
    {
        return x - y;
    }

    int multiply(int x, int y)
    {
        return x * y;
    }

    int divide(int x, int y)
    {
        if(0 != y)
        {
            return x/y;
        }
        else
        {
            cout << "除数不能为0" << endl;
            return 1 << 31;
        }
    }
};

class AbstractCalculator
{
public:
    virtual int getResult(int x, int y) = 0;
    virtual ~AbstractCalculator() {}
};

class PlusCalculator
: public AbstractCalculator
{
public:
    int getResult(int x, int y)
    {
        return x + y;
    }
};

class MinusCalculator
: public AbstractCalculator
{
public:
    int getResult(int x, int y)
    {
        return x - y;
    }
};

class MultiplyCalculator
: public AbstractCalculator
{
public:
    int getResult(int x, int y)
    {
        return x * y;
    }
};

class DivideCalculator
: public AbstractCalculator
{
public:
    int getResult(int x, int y)
    {
        if(0 != y)
        {
            return x/y;
        }
        else
        {
            cout << "除数不能为0" << endl;
            return 1 << 31;
        }
    }
};

int main(int argc, char **argv)
{
    cout << "Hello world" << endl;
    return 0;
}

