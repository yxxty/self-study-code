#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;

void test()
{
    int a = 10;
    int b = 20;
    int *pflag = &a;
    string s1 = "hello";
    string s2 = "world";

    //左值引用只能绑定到左值，不能绑定到右值
    //const左值引用既可以绑定到左值也可以绑定到右值
    const int &ref = a;
    const int &ref2 = 10;

    //右值引用,C++11提出来的
    int &&rref = 10;//可以绑定到右值
    /* int &&rref2 = a;//error, 右值引用不能绑定到左值 */

    &rref;

    &ref;//lvalue

    &a;
    &b;
    &pflag;
    &(*pflag);//lvalue
    &s1;
    &s2;

    /* &(a + b);//error, rvalue */
    /* &(s1 + s2);//error, rvalue */
}
int main(int argc, char **argv)
{
    cout << "Hello world" << endl;
    return 0;
}

